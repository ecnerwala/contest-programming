#include "aliens_c.h"

long long take_photos(int n, int m, int k, int* r, int* c) {
    return 0;
}
