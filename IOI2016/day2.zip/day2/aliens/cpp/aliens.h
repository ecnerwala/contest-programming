#pragma once

#include <vector>

long long take_photos(int n, int m, int k, std::vector<int> r, std::vector<int> c);

