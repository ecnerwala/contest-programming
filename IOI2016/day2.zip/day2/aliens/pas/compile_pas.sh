#!/bin/bash

problem=aliens

fpc -XS -O2 -o$problem grader.pas
