#!/bin/bash

problem=messy

fpc -XS -O2 -o$problem grader.pas
