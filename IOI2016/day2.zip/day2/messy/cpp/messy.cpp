#include <vector>

#include "messy.h"

std::vector<int> restore_permutation(int n, int w, int r) {
    add_element("0");
    compile_set();
    check_element("0");
    return std::vector<int>();
}
