public class messy {

    public int[] restore_permutation(int n, int w, int r) {
        grader.add_element("0");
        grader.compile_set();
        grader.check_element("0");
        return new int[0];
    }
}
