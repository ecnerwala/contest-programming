#pragma once

void add_element(char* x);
int check_element(char* x);
void compile_set();

void restore_permutation(int n, int w, int r, int* result);
