#include "paint.h"

#include <cstdlib>

std::string solve_puzzle(std::string s, std::vector<int> c) {
    return "";
}
