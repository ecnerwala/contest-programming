#!/bin/bash

problem=paint

fpc -XS -O2 -o$problem grader.pas
