public class railroad {
    public static long plan_roller_coaster(int[] s, int[] t) {
        int n = s.length;
        return 0;
    }
}
