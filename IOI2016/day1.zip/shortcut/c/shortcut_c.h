#pragma once

long long find_shortcut(int n, int* l, int* d, int c);
