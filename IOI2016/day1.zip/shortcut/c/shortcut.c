#include "shortcut_c.h"

long long find_shortcut(int n, int* l, int* d, int c)
{
    return 0;
}
