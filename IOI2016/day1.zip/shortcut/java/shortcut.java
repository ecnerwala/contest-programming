public class shortcut {
    public long find_shortcut(int n, int[] l, int[] d, int c) {
        return 0;
    }
}
