#include "shortcut.h"

long long find_shortcut(int n, std::vector<int> l, std::vector<int> d, int c)
{
    return 0;
}
