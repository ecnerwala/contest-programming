public class molecules {

    public int[] find_subset(int l, int u, int[] w) {
        return new int[0];
    }                       

}
