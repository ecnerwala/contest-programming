#pragma once

#include <vector>

std::vector<int> find_subset(int l, int u, std::vector<int> w);
