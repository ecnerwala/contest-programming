#pragma once

int find_subset(int l, int u, int* w, int w_len, int* result);
