#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define ppb pop_back
#define F first
#define S second 

template <typename T> void smin(T &a, T b) { a = min(a, b); }
template <typename T> void smax(T &a, T b) { a = max(a, b); }

const int maxn = 1e5 + 10, m = 10;

int a[maxn], curcnt[m + 10], answer;
vector <int> cur;
vector <vector <int>> vec;

void bt(int i, int w) {
	if (!w) {
		vec.pb(cur);
		return;
	}
	if (i == m + 1)
		return;
	int lim = w / i;
	for (int j = 0; j < lim; ++j)
		cur.pb(i);
	w -= lim * i;
	for (int j = lim; ~j; --j) {
		bt(i + 1, w);
		if (j) {
			cur.ppb();
			w += i;
		}
	}
	return;
}

bool cmp(const vector <int> v1, const vector <int> v2) {
	int s1 = v1.size(), s2 = v2.size();
	double sum1 = 0, sum2 = 0;
	for (auto i: v1)
		sum1 += pow(1.5, i);
	for (auto i: v2)
		sum2 += pow(1.5, i);
	return sum1 * s2 > sum2 * s1;
}

pair<int, vector<int>> solve(int n)
{
	static int cnt[m + 10], ans[maxn];
	static vector <int> ind[m + 10];
	for(int i = 0; i < n; i++) {
		++cnt[a[i]];
		ind[a[i]].pb(i);
	}
	for (int i = 20; i; --i) {
		vec.clear();
		bt(1, i);
		sort(vec.begin(), vec.end(), cmp);
		for (auto j: vec) {
			int k = maxn;
			memset(curcnt, 0, sizeof(curcnt));
			for (auto d: j)
				curcnt[d]++;
			for (int d = 1; d <= m; ++d)
				if (curcnt[d])
					smin(k, cnt[d] / curcnt[d]);
			for (int d = 1; d <= m; ++d)
				cnt[d] -= curcnt[d] * k;
			for (auto d: j) {
				for (int t = 0; t < k; ++t)
					ans[ind[d][t]] = answer + t + 1;
				ind[d].erase(ind[d].begin(), ind[d].begin() + k);
			}
			answer += k;
		}
	}
	vector<int> Ans(n);
	for(int i = 0; i < n; i++) Ans[i] = ans[i];
	return {answer, Ans};
}

int ANS[3][maxn], aa[100];
vector<int> v[12];
vector<vector<int> > bus;

void BT(int n, int ind, int MAX)
{
	if(n < 0)
		return;
	if(n == 0)
	{
		vector<int> g;
		for(int i = 0; i < ind; i++)
			g.pb(aa[i]);
		bus.pb(g);
		return;
	}
	for(int i = MAX; i > 0; i--)
	{
		aa[ind] = i;
		BT(n - i, ind + 1, i);
	}
}

int po[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20};

bool cmp1(vector<int> v1, vector<int> v2)
{
	int sum1 = 0, sum2 = 0;
	for(int x : v1)
		sum1 += x;
	for(int x : v2)
		sum2 += x;
	if(sum1 == sum2 && v1.size() == v2.size())
		return v1.back() > v2.back();
	return -po[v1.size()] + sum1 < -po[v2.size()] + sum2;
}

bool cmp2(vector<int> v1, vector<int> v2)
{
	int sum1 = 0, sum2 = 0;
	for(int x : v1)
		sum1 += x;
	for(int x : v2)
		sum2 += x;
	if(sum1 == sum2 && v1.size() == v2.size())
		return v1.back() > v2.back();
	return -po[v1.size()] + sum1 - v1.back() / 4 < -po[v2.size()] + sum2 - v2.back() / 4;
}

pair<int, vector<int>> solve2(int n)
{
	for(int i = 20; i > 0; i--)
		BT(i, 0, 10);
	int ind[3] = {};
	for(int t = 0; t < 3; t++)
	{
		if(t == 0)
			sort(bus.begin(), bus.end(), cmp1);
		else if(t == 1)
			sort(bus.begin(), bus.end(), cmp2);
		else
		{
			bus.clear();
			for(int i = 20; i > 0; i--)
				BT(i, 0, 10);
			sort(bus.begin(), bus.end(), cmp2);
		}
		reverse(bus.begin(), bus.end());
		for(int i = 0; i < n; i++)
			v[a[i]].pb(i);
		for(int i = 0; i < int(bus.size()); i++)
		{
			int cnt[12] = {};
			for(int x : bus[i])
				cnt[x]++;
			bool flag = false;
			for(int j = 1; j <= 10; j++)
				if(cnt[j] > int(v[j].size()))
					flag = true;
			if(!flag)
			{
				for(int j = 1; j <= 10; j++)
					for(int k = 0; k < cnt[j]; k++)
					{
						ANS[t][v[j].back()] = ind[t];
						v[j].pop_back();
					}
				ind[t]++;
				i--;
			}
		}
	}
	vector<int> ans(n);
	int mx = min({ind[0], ind[1], ind[2]});
	if(ind[0] <= ind[1] && ind[0] <= ind[2])
	{
		for(int i = 0; i < n; i++)
			ans[i] = ANS[0][i] + 1;
	}
	else if(ind[1] <= ind[2])
	{
		for(int i = 0; i < n; i++)
			ans[i] = ANS[1][i] + 1;
	}
	else
	{
		for(int i = 0; i < n; i++)
			ans[i] = ANS[2][i] + 1;
	}
	return {mx, ans};
}

int main(){
	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
	int n, k;
	cin >> n >> k;
	for (int i = 0; i < n; ++i) {
		cin >> a[i];
	}
	
	pair<int, vector<int>> ans2 = solve2(n);
	pair<int, vector<int>> ans1 = solve(n);
	if(ans1.F > ans2.F) swap(ans1, ans2);
	cout<< ans1.F << '\n';
	for(auto u : ans1.S)
		cout<< u - 1 << ' ';
	cout<< '\n';
	return 0;
}

