#include<iostream>
#include<algorithm>
#include<vector>

#define PB push_back

using namespace std;

const int MAXN = 100005;
int a[MAXN], ans[3][MAXN], aa[100];
vector<int> v[12];
vector<vector<int> > bus;

void BT(int n, int ind, int MAX)
{
	if(n < 0)
		return;
	if(n == 0)
	{
		vector<int> g;
		for(int i = 0; i < ind; i++)
			g.PB(aa[i]);
		bus.PB(g);
		return;
	}
	for(int i = MAX; i > 0; i--)
	{
		aa[ind] = i;
		BT(n - i, ind + 1, i);
	}
}

int po[] = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20};

bool cmp(vector<int> v1, vector<int> v2)
{
	int sum1 = 0, sum2 = 0;
	for(int x : v1)
		sum1 += x;
	for(int x : v2)
		sum2 += x;
	if(sum1 == sum2 && v1.size() == v2.size())
		return v1.back() > v2.back();
	return -po[v1.size()] + sum1 < -po[v2.size()] + sum2;
}

bool cmp2(vector<int> v1, vector<int> v2)
{
	int sum1 = 0, sum2 = 0;
	for(int x : v1)
		sum1 += x;
	for(int x : v2)
		sum2 += x;
	if(sum1 == sum2 && v1.size() == v2.size())
		return v1.back() > v2.back();
	return -po[v1.size()] + sum1 - v1.back() / 4 < -po[v2.size()] + sum2 - v2.back() / 4;
}

int main()
{
	for(int i = 20; i > 0; i--)
		BT(i, 0, 10);
	//	for(int i = bus.size(); i > bus.size() - 100; i--, cout << endl)
	//		for(int x : bus[i])
	//			cout << x << ' ';
	int n, k;
	cin >> n >> k;
	for(int i = 0; i < n; i++)
		cin >> a[i];
	int ind[3] = {};
	for(int t = 0; t < 3; t++)
	{
		if(t == 0)
			sort(bus.begin(), bus.end(), cmp);
		else if(t == 1)
			sort(bus.begin(), bus.end(), cmp2);
		else
		{
			bus.clear();
			for(int i = 20; i > 0; i--)
				BT(i, 0, 10);
			sort(bus.begin(), bus.end(), cmp2);
		}
		reverse(bus.begin(), bus.end());
		for(int i = 0; i < n; i++)
			v[a[i]].PB(i);
		for(int i = 0; i < bus.size(); i++)
		{
			int cnt[12] = {};
			for(int x : bus[i])
				cnt[x]++;
			bool flag = false;
			for(int j = 1; j <= 10; j++)
				if(cnt[j] > v[j].size())
					flag = true;
			if(!flag)
			{
				for(int j = 1; j <= 10; j++) {
					for(int k = 0; k < cnt[j]; k++)
					{
						if(!v[j].size()) continue;
						ans[t][v[j].back()] = ind[t];
						v[j].pop_back();
					}
				}
				ind[t]++;
				i--;
			}
		}
	}

	if(ind[0] <= ind[1] && ind[0] <= ind[2])
	{
		cout << ind[0] << endl;
		for(int i = 0; i < n; i++)
			cout << ans[0][i] << ' ';
		cout << endl;
	}
	else if(ind[1] <= ind[2])
	{
		cout << ind[1] << endl;
		for(int i = 0; i < n; i++)
			cout << ans[1][i] << ' ';
		cout << endl;
	}
	else
	{
		cout << ind[2] << endl;
		for(int i = 0; i < n; i++)
			cout << ans[2][i] << ' ';
		cout << endl;
	}

	return 0;
}

