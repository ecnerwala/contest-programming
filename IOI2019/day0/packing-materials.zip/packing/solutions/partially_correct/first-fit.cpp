	//     . .. ... .... ..... be name khoda ..... .... ... .. .     \\

#include <bits/stdc++.h>
using namespace std;

typedef long long ll;
typedef long double ld;
int in() { int x; scanf("%d", &x); return x; }

const int N = 100000;

int a[N];
int res[N];

int main() {
	int n, k;
	cin >> n >> k;
	int cur = 0, l = 0;
	for(int i = 0; i < n; i++) {
		int x = in();
		if(cur + x > 20) {
			cur = 0;
			l++;
		}
		cur += x;
		res[i] = l;
	}
	cout << l + 1 << endl;
	for(int i = 0; i < n; i++)
		cout << res[i] << " ";
	cout << endl;
}
