#include <bits/stdc++.h>

using namespace std;

#define pb push_back
#define ppb pop_back

template <typename T> void smin(T &a, T b) { a = min(a, b); }
template <typename T> void smax(T &a, T b) { a = max(a, b); }

const int maxn = 1e5 + 10, m = 10;
int n, a[maxn], cnt[m + 10], curcnt[m + 10], ans[maxn], answer;
vector <int> ind[m + 10], cur;
vector <vector <int>> vec;

void bt(int i, int w) {
	if (!w) {
		vec.pb(cur);
		return;
	}
	if (i == m + 1)
		return;
	int lim = w / i;
	for (int j = 0; j < lim; ++j)
		cur.pb(i);
	w -= lim * i;
	for (int j = lim; ~j; --j) {
		bt(i + 1, w);
		if (j) {
			cur.ppb();
			w += i;
		}
	}
	return;
}

bool cmp(const vector <int> v1, const vector <int> v2) {
	int s1 = v1.size(), s2 = v2.size();
	double sum1 = 0, sum2 = 0;
	for (auto i: v1)
		sum1 += pow(1.5, i);
	for (auto i: v2)
		sum2 += pow(1.5, i);
	return sum1 * s2 > sum2 * s1;
}

int main(){
	ios::sync_with_stdio(0), cin.tie(0), cout.tie(0);
	int k;
	cin >> n >> k;
	for (int i = 0; i < n; ++i) {
		cin >> a[i];
		++cnt[a[i]];
		ind[a[i]].pb(i);
	}
	for (int i = 20; i; --i) {
		vec.clear();
		bt(1, i);
		sort(vec.begin(), vec.end(), cmp);
		for (auto j: vec) {
			int k = maxn;
			memset(curcnt, 0, sizeof(curcnt));
			for (auto d: j)
				curcnt[d]++;
			for (int d = 1; d <= m; ++d)
				if (curcnt[d])
					smin(k, cnt[d] / curcnt[d]);
			for (int d = 1; d <= m; ++d)
				cnt[d] -= curcnt[d] * k;
			for (auto d: j) {
				for (int t = 0; t < k; ++t)
					ans[ind[d][t]] = answer + t + 1;
				ind[d].erase(ind[d].begin(), ind[d].begin() + k);
			}
			answer += k;
		}
	}
	cout << answer << '\n';
	for (int i = 0; i < n; ++i)
		cout << ans[i] - 1 << ' ';
	cout << '\n';
	return 0;
}

