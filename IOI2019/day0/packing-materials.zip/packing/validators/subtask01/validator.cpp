#include <bits/stdc++.h>
#include "testlib.h"

using namespace std;

const int maxn = 1e5;

int main(int argc, char* argv[]) {
	registerValidation(argc, argv);
	int n = inf.readInt(1, maxn, "n");
	inf.readSpace();
	inf.readInt(1, maxn, "k");
	inf.readEoln();
	for (int i = 0; i < n; ++i) {
		inf.readInt(1, 10, "a_i");
		if (i < n - 1)
		    inf.readSpace();
	}
	inf.readEoln();
	inf.readEof();
}
