# Packing

IOI 2019 host is planning to give t-shirts to all participants. The most challenging part of this plan is the packing process.

There are $n$ t-shirts, numbered from $0$ to $n-1$.
Each t-shirt $i$ has a volume (size) $A[i]$, which is a positive integer not exceeding $10$ (XXXS, XXS, XS, S, M, L, XL, XXL, XXXL, XXXXL).
There are $k$ boxes available for packing the t-shirts, numbered from $0$ to $k - 1$.
The capacity of each box is $20$, so the total volume of t-shirts in each of the boxes must not exceed $20$.
Of course, there is always an option of purchasing more boxes to make the packing easier. 

A packing plan can be shown as an array $P$ of $n$ integers, where $P[i]$ indicates the number of the box where the t-shirt number $i$ should be put. 

You are given the volumes of the t-shirts. 
Your task is to help IOI 2019 in packing the t-shirts, such that as few as possible extra boxes (ideally, no extra boxes) are needed.

## Implementation details

This is an output-only task with partial scoring.
You are given $10$ input files, each containing integers $n$, $k$, and array $A$ of $n$ integers.
For each input file, you should submit an output file containing the packing plan.
For each output file, you will get points based on the score of your packing plan.

You are not supposed to submit any source code for this task.


### Input format

The input is in the following format:
* line $1$: $\;\;n\;\;k$
* line $2$: $\;\; A[0] \;\; A[1] \;\; \ldots \;\; A[n-1]$ (The volumes)



### Output format

The output must be in the following format:
* line $1$: $\;\;l$ (total number of boxes needed)
* line $2$: $\;\; P[0] \;\; P[1] \;\; \ldots \;\; P[n-1]$ (the packing plan)



## Constraints

* $1 \leq n, k \leq 100,000$
* $1 \leq A[i] \leq 10$ (for $0 \leq i \leq n-1$).


## Scoring

An output file is considered to be *valid* if all the following conditions are met:
* The output must match the described format.
* $0 \leq P[i] \leq l-1$ (for all $i$ where $0 \leq i \leq n-1$).
* The total volume of t-shirts assigned to each box must not exceed $20$.

Your score for a test case will be $0$ if your output for that test case is not valid.
Otherwise, let $R$ be $k / l$.
Your score will then be calculated as follows.

| condition | score |
| :-----------: | :---: |
| $R \leq 0.75$ | $8R/3$   |
| $0.75 < R < 1$ | $ 1 + 9^{4 (R - 0.75)}$  |
| $1 \leq R$    | $10$  |

For each test case, there exists a packing plan that scores $10$ points.


## Example

Here is a sample input:
```
5 2
6 7 10 7 10
```

In this example, the best possible result uses $2$ boxes.
Below is a result using only $2$ boxes, which gets $10$ points. 
```
2
0 0 1 0 1
```

Below is another possible valid output, which gets $\frac 2 3 \cdot \frac 8 3 \approx 1.778$ points.
```
3
0 2 1 0 1
```

Here is another sample input:
```
7 4
8 8 8 8 8 8 8
```

Below is a possible valid output, which gets $10$ points.
```
4
0 1 2 3 2 1 0
```
And this is another possible valid output, which gets $1 + 9 ^ {4(\frac 4 5 - 0.75)} = 1 + 9^{0.2} \approx 2.552$ points.
```
5
0 0 1 1 2 3 4 
```
