//			be name khoda
#include "testlib.h"
#include <algorithm>
#include <map>
using namespace std;

typedef long double ld;
const int N = 100000;

int sum[N];

int main(int argc, char * argv[]) {
	registerChecker("packing", argc, argv);
	int n = inf.readInt();
	inf.readSpace();
	int k = inf.readInt();
	int val = ouf.readInt();
	ouf.readEoln();
	inf.readEoln();
	vector <int> p;
	for (int i = 0; i < n; i++) {
		int x = inf.readInt(0, 10);
		int y = ouf.readInt(0, val - 1, "box number out of range");
		sum[y] += x;
		if(sum[y] > 20) {
			quitf(_wa, "box number %d is overloaded.", y);
		}
		if(i + 1 < n) {
			inf.readSpace();
			ouf.readSpace();
		}
	}
	ld ratio = k;
	ratio /= val;
	cerr << k << ", " << val << " -> ratio = " << ratio << endl;
	ratio = min<ld>(ratio, 1.1);
	if(ratio <= 0.75) {
		quitp((ratio * 2 / 0.75)/10.0);
	}
	if(ratio + 1e-5 >= 1)
		quitp(1);
	quitp(min<ld>(1.0, (1 + pow(9, max<ld>(0, (ratio - 0.75) * 4)))/10.0));
	return 0;
}
