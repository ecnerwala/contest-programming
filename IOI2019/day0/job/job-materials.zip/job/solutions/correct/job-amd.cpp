//	CREATED BY AMIRMOHAMMD DEHGHAN
#include <bits/stdc++.h>
using namespace std;
#define all(v)	(v).begin(), (v).end()

typedef long long ll;
typedef vector<int> vi;


const int maxn = 2e5 + 100;
ll ans;
vi adj[maxn];
int u[maxn], d[maxn], p[maxn];
struct job {
	ll u, d;
	job(int U, int D){
		u = U;
		d = D;
	}
	inline void merge(job j) {
		::ans += d * j.u;
		u += j.u;
		d += j.d;
	}
	inline int cmp(job j){ // -1: less that, 0: equal, +1: greater than
		ll a = u * j.d;
		ll b = j.u * d;
		return (a < b? -1: a == b? 0 : +1);
	}
};


struct job_cmp {
	bool operator ()(job a, job b) {
		return a.cmp(b) == -1;
	}
};


set<job, job_cmp> se[maxn];

inline job get_last(int x) {
	auto it = se[x].end();
	-- it;
	return *it;
}

inline set<job, job_cmp>::iterator get_last_iter(int x) {
	auto it = se[x].end();
	-- it;
	return it;
}


inline int dfs(int v){
	vi children;
	int res = v;
	int big = -1; // index in children
	for(int u: adj[v]) {
		children.push_back(dfs(u));
		if (big == -1 || se[children.back()].size() > se[children[big]].size())
			big = (int)children.size() - 1;
	}
	job j = job(u[v], d[v]);
	if(big == -1){ // leaf
		se[res].insert(j);
		return res;
	}
	res = children[big];
	for(int i = 0; i < children.size(); ++ i) 
		if(i != big) {
			for(auto jj: se[children[i]]) {
				auto it = se[res].lower_bound(jj);
				if(it != se[res].end() && jj.cmp(*it) == 0) {
					jj.merge(*it);
					se[res].erase(it);
				}
				se[res].insert(jj);
			}
			se[children[i]].clear();
		}
	while(!se[res].empty() && j.cmp(get_last(res)) != +1) {
		j.merge(get_last(res));
		se[res].erase(get_last_iter(res));
	}
	se[res].insert(j);
	return res;
}

ll scheduling_cost(vector<int> P, vector<int> U, vector<int> D) {
	int n = U.size();
	for(int i = 0; i < n; ++ i) {
		u[i] = U[i];
		d[i] = D[i];
		p[i] = P[i];
		ans += (ll)u[i] * (ll)d[i];
		if (~p[i])
			adj[p[i]].push_back(i);
	}
	int x = dfs(0);
	ll d = 0;
	while(!se[x].empty()) {
		job j = get_last(x);
		ans += d * j.u;
		d += j.d;
		se[x].erase(get_last_iter(x));
	}
	return ans;

}
