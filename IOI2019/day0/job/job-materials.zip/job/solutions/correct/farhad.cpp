#include <iostream>
#include <cassert>
#include <set>
#include <vector>

using namespace std;

const int kMax = 200 * 1000 + 10;

class Node {
 public:
	Node() = default;
	Node(int root, int duration, int cost) :
		root_(root),
		duration_(duration),
		cost_(cost) {}

	void AddImmediate(Node* node) {
		immediates_.push_back(node);
		duration_ += node->duration_;
		cost_ += node->cost_;
	}

	void set_height(int height) { height_ = height; }

	void CreateOrder(vector<int>* v) {
		if (root_) {
			v->push_back(root_);
		}
		for (Node* child : immediates_) {
			child->CreateOrder(v);	
		}
	}

	bool operator < (const Node& node) const {
		if (root_ == 0) return false;
		if (node.root_ == 0) return true;
		const auto lhs = this->cost_ * node.duration_;
		const auto rhs = node.cost_ * this->duration_;
		return lhs != rhs ? lhs > rhs : height_ > node.height_;
	}

  private:
	long long duration_, cost_;
	int root_;
	int height_;
	vector<Node*> immediates_;
} nodes[kMax];

vector<int> children[kMax];

struct Comparator {
	bool operator ()(const Node* lhs, const Node* rhs) const {
			return *lhs < *rhs;
	}
};

using Q = multiset<Node*, Comparator>;
Q DFS(int idx, int height) {
	Q q;
	for (int i : children[idx]) {
		Q child_q = DFS(i, height + 1);
		if (q.size() > child_q.size()) {
			q.insert(child_q.begin(), child_q.end());
		} else {
			child_q.insert(q.begin(), q.end());
			q = std::move(child_q);
		}
	}
	Node* node = nodes + idx;
	node->set_height(height);
	Comparator c;
	while (!q.empty() && c(*q.begin(), node)) {
		node->AddImmediate(*q.begin());
		q.erase(q.begin());
	}
	q.insert(node);
	return q;
}

long long scheduling_cost(vector<int> P, vector<int> U, vector<int> D) {
  int n = U.size();
	for (int i = 0; i < n; ++i) {
		nodes[i + 1] = Node(i + 1, D[i], U[i]);
		children[P[i] + 1].push_back(i + 1);
	}
	nodes[0] = Node(0, 1, 0);
	const auto q = DFS(0, 0);
	assert(q.size() == 1);
	vector<int> v;
	v.reserve(n);
	(*q.begin())->CreateOrder(&v);
	long long time = 0, cost = 0;
	for (int i = 0; i < n; ++i) {
		time += D[v[i] - 1];
		cost += U[v[i] - 1] * time;
	}
	return cost;
}
