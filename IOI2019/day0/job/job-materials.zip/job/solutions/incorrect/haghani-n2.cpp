#include <algorithm>
#include <iostream>
using namespace std;
const int MAX = 5005;
long long dp[MAX][MAX], s1[MAX], s2[MAX];
int par[MAX][MAX];
vector<pair<int, int> > solve(vector<pair<int, int> > v1, vector<pair<int, int> > v2)
{
	s1[0] = s2[0] = 0;
	for (int i = 1; i <= (int)v1.size(); i++)
		s1[i] = s1[i - 1] + v1[i - 1].first;
	for (int j = 1; j <= (int)v2.size(); j++)
		s2[j] = s2[j - 1] + v2[j - 1].first;
	for (int i = 0; i <= (int)v1.size(); i++)
		for (int j = 0; j <= (int)v2.size(); j++)
		{
			if (i == 0 && j == 0)
			{
				dp[i][j] = 0;
				continue;
			}
			long long t = s1[i] + s2[j];
			if (i == 0)
			{
				dp[i][j] = dp[i][j - 1] + t * v2[j - 1].second;
				par[i][j] = 1;
				continue;
			}
			if (j == 0)
			{
				dp[i][j] = dp[i - 1][j] + t * v1[i - 1].second;
				par[i][j] = 0;
				continue;
			}
			dp[i][j] = min(dp[i - 1][j] + t * v1[i - 1].second, dp[i][j - 1] + t * v2[j - 1].second);
			if (dp[i - 1][j] + t * v1[i - 1].second < dp[i][j - 1] + t * v2[j - 1].second)
				par[i][j] = 0;
			else
				par[i][j] = 1;
		}
	vector<pair<int, int> > res;
	int i = v1.size(), j = v2.size();
	while (i > 0 || j > 0)
		if (par[i][j] == 0)
			res.push_back(v1[--i]);
		else
			res.push_back(v2[--j]);
	reverse(res.begin(), res.end());
	return res;
}
vector<int> adj[MAX];
int u[MAX], d[MAX];
vector<pair<int, int> > dfs(int v)
{
	vector<pair<int, int> > ans;
	if (adj[v].empty())
	{
		ans.push_back(make_pair(d[v], u[v]));
		return ans;
	}
	for (int i = 0; i < (int)adj[v].size(); i++)
		ans = solve(ans, dfs(adj[v][i]));
	reverse(ans.begin(), ans.end());
	ans.push_back(make_pair(d[v], u[v]));
	reverse(ans.begin(), ans.end());
	return ans;
}
long long scheduling_cost(vector<int> _par, vector<int> _u, vector<int> _d) {
	int n = _u.size();
	for (int i = 0; i < n; i++)
	{
		u[i] = _u[i];
		d[i] = _d[i];
		if (_par[i] != -1)
			adj[_par[i]].push_back(i);
	}
	vector<pair<int, int> > ans = dfs(0);
	long long res = 0, t = 0;
	for (int i = 0; i < (int)ans.size(); i++)
	{
		t += ans[i].first;
		res += t * ans[i].second;
	}
	return res;

}
