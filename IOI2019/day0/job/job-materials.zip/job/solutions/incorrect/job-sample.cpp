#include "job.h"

using namespace std;
long long scheduling_cost(vector<int> p, vector<int> u, vector<int> d) {
	return 0;
}
