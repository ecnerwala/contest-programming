
class job {

    public long scheduling_cost(int[] p, int[] u, int[] d) {
		return 0;
    }

}
