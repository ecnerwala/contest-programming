//	CREATED BY AMIRMOHAMMD DEHGHAN
#include <bits/stdc++.h>
using namespace std;
#define all(v)	(v).begin(), (v).end()

typedef long long ll;
typedef vector<int> vi;


const int maxn = 2e5 + 100;
ll ans;

ll scheduling_cost(vector<int> P, vector<int> U, vector<int> D) {
	int n = U.size();
	ll t = 0;
	for(int i = 0; i < n; ++ i) {
		t += D[i];
		ans += U[i] * t;
	}
	return ans;

}
