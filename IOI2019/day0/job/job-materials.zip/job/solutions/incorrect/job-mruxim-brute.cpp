// ... ... .. ....!
// ... ....... .... ...!

#include<bits/stdc++.h>
using namespace std;

#define rep(i, n) for(int i = 0, i##__n = (int)(n); i < i##__n; ++i)
#define fer(i, a, b) for(int i = (int)(a), i##__b = (int)(b); i < i##__b; ++i)
#define rof(i, b, a) for(int i = (int)(b), i##__a = (int)(a); i-- > i##__a; )
#define sz(x) (int((x).size()))
#define pb push_back
#define all(x) (x).begin(), (x).end()
#define X first
#define Y second
//#define endl '\n'

template<class P, class Q> inline void smin(P &a, Q b) { if (b < a) a = b; }
template<class P, class Q> inline void smax(P &a, Q b) { if (a < b) a = b; }

typedef long long ll;
typedef pair<int, int> pii;

////////////////////////////////////////////////////////////////////////////////

const int maxn = 200000 + 100;

int n;
int par[maxn];

struct Job {
	ll urg, dur;
	bool operator<(Job j) const {
		return urg * j.dur > j.urg * dur;
	}
} jobs[maxn];

ll dp[1<<25];

long long scheduling_cost(vector<int> P, vector<int> U, vector<int> D) {
	int n = sz(U);
	rep(i, n) jobs[i].urg = U[i], jobs[i].dur = D[i];
	int root = -1;
	rep(i, n) {
		par[i] = P[i];
		if(par[i] == -1)
			root = i;
	}

	if(n > 26) return 0;

	memset(dp, 50, sizeof dp);
	dp[0] = 0;

	// still assumes root = 0
	for(int mask = 1; mask < (1 << (n-1)); mask++) {
		int cmask = (mask << 1) | 1;
		int st = 0;

		for(int i = 0; i < n; i++)
			if(cmask >> i & 1)
				st += jobs[i].dur;

		for(int i = 1; i < n; i++)
			if((cmask >> i & 1) && (cmask >> par[i] & 1))
				smin(dp[mask], dp[(cmask ^ (1 << i)) >> 1] + jobs[i].urg * (st - jobs[i].dur));
	}

	ll add = 0;
	rep(i, n) add += U[i] * D[i];

	return dp[(1 << (n - 1)) - 1] + add;
}

