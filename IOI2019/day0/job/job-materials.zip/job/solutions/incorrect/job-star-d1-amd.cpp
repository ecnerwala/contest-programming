//	CREATED BY AMIRMOHAMMD DEHGHAN
#include <bits/stdc++.h>
using namespace std;
#define all(v)	(v).begin(), (v).end()
#define x	first
#define y	second

typedef long long ll;
typedef vector<int> vi;
typedef pair<int, int> pii;

const int maxn = 2e5 + 100;
ll ans;

ll scheduling_cost(vector<int> P, vector<int> U, vector<int> D) {
	int n = U.size();
	ll t = D[0];
	ans += 1LL * D[0] * U[0];
	vector<pii> v;
	for(int i = 1; i < n; ++ i) 
		v.push_back(pii(U[i], D[i]));
	sort(all(v));
	reverse(all(v));
	for(int i = 0; i < v.size(); ++ i) {
		int u = v[i].x;
		int d = v[i].y;
		t += d;
		ans += u * t;
	}
	return ans;

}
