#include "testlib.h"
using namespace std;

const int maxn = 200000;
const int maxu = 10000;
const int maxd = 10000;

static string input_secret = "7482365a-669a-4a64-887e-b4b620a595e9";

int main() {
	registerValidation();
	string secret = inf.readLine();
	ensuref(secret == input_secret, "Secret not found!");

	int n = inf.readInt(1, maxn, "n");
	inf.readEoln();

	int a = 0, b = 0;

	for(int i = 0; i < n; i++) {
		if(i) inf.readSpace();
		if(i == 0)
			inf.readInt(-1, -1, ("P_" + to_string(i)).c_str());
		else {
			int x = inf.readInt(0, i - 1, ("P_" + to_string(i)).c_str());
			if(x == a)
				a = i;
			else if(x == b)
				b = i;
			else ensuref(0, "tree isn't two paths");
		}
	}
	inf.readEoln();
	
	for(int i = 0; i < n; i++) {
		if(i) inf.readSpace();
		inf.readInt(1, maxu, ("U_" + to_string(i)).c_str());
	}
	inf.readEoln();

	for(int i = 0; i < n; i++) {
		if(i) inf.readSpace();
		inf.readInt(1, maxd, ("D_" + to_string(i)).c_str());
	}
	inf.readEoln();
	
	inf.readEof();

	return 0;
}
