#include "testlib.h"
using namespace std;

static string output_secret = "4915f9c2-60f4-4426-9336-0bd7a6405de6";

int main(int argc, char * argv[])
{
	registerChecker("job", argc, argv);

	readBothSecrets(output_secret);
	readBothGraderResults();

	compareRemainingLines(3);
}
