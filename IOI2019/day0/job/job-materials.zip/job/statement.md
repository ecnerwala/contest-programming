# Job Scheduling

The "Land of Fire" is famous for its "Temple of Fire" - Ateshgah.
To accomodate more visitors, as a master architect, you are planning to build more temples.
You have one builder and $n$ temples to build.
Temples are numbered from $0$ to $n-1$.
According to the plan, each temple $i$ has a prerequisite temple $p[i]$ that should be built before temple $i$.
Only temple $0$ has $p[0] = -1$, which means this temple can be built right away at time $0$.
Temple $i$ takes $d[i]$ seconds to build, and finishing it at time $t$ costs $t*u[i]$.

Find the minimum cost to build all the temples.

[//]: # "There are $n$ jobs, which need to be executed."
[//]: # "Each job has an urgency $u_i$, a duration $d_i$ and a parent job $p_i$."
[//]: # "Each job can only be executed after its parent job is done."
[//]: # "Each job is executed without interruption."
[//]: # "Minimize the cost of scheduling all jobs."


## Implementation details

You should implement the following procedure:

```
int64 scheduling_cost(int[] p, int[] u, int[] d)
```

* $p$, $u$ and $d$: integer arrays of length $n$.
* This procedure should return the minimum cost of building all temples.


## Examples

### Example 1

Consider the following call.

```
scheduling_cost([-1, 0, 0], [5, 2, 5], [3, 4, 1])
```

The answer is $51$.

## Constraints

* $1 \leq n \leq 200\,000$
* $p[0] = -1$
* $0 \leq p[i] \leq i-1$ (for all $1 \leq i \leq n-1$)
* $0 \leq u[i] \leq 10\,000$ (for all $0 \leq i \leq n-1$)
* $0 \leq d[i] \leq 10\,000$ (for all $0 \leq i \leq n-1$)


## Subtasks

1. (5 points) $p[i] = i-1$ (for all $1 \leq i \leq n-1$)
1. (7 points) $p[i] = 0$ (for all $1 \leq i \leq n-1$) and $d[i] = 1$ (for all $0 \leq i \leq n-1$)
1. (12 points) $p[i] = 0$ (for all $1 \leq i \leq n-1$)
1. (18 points) Temple $0$ is prerequisite of at most $2$ other temples, and all other temples are prerequisite of at
   most $1$ other temple.
1. (21 points) $n \leq 200$
1. (37 points) No additional constraints.


## Sample grader

The sample grader reads the input in the following format:
* line $1$:  $\;\;n$
* line $2$:  $\;\;p[0] \;\; p[1] \;\; p[2] \;\ldots\;  p[n-1]$
* line $3$:  $\;\;u[0] \;\; u[1] \;\; u[2] \;\ldots\;  u[n-1]$
* line $4$:  $\;\;d[0] \;\; d[1] \;\; d[2] \;\ldots\;  d[n-1]$

The sample grader prints a single line containing the return value of `scheduling_cost`.
