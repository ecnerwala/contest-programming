#include "transfer.h"
using namespace std;

//Author: Kian Mirjalali
//K = 2*N+1

typedef vector<int> VI;

VI get_attachment(VI source) {
	const int N = source.size();
	VI attachment = source;
	attachment.insert(attachment.end(), source.begin(), source.end());
	attachment.push_back(0);
	return attachment;
}

VI retrieve(VI data) {
	const int N = (data.size()-1)/3;
	VI result(N, 0);
	for (int i=0; i<N; i++)
		if (data[i]+data[N+i]+data[2*N+i] > 1)
			result[i] = 1;
	return result;
}
