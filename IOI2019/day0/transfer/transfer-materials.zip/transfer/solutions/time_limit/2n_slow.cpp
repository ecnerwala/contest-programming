#include "transfer.h"
#include <iostream>
using namespace std;

//Author: Kian Mirjalali
//K = 2*N

typedef vector<int> VI;

static inline int callLimit(int N) {
	switch (N) {
	case 63:  return 20000;
	case 255: return 200000;
	}
	cerr << "invalid value of N: " << N << endl;
	exit(1);
}

static inline void burnCpu(int steps) {
	int temp = 0;
	for (int i=0; i<steps; i++)
		if (i*i+i == temp)
			temp++;
	if (temp == -1)
		cerr << "impossible" << endl;
}

VI get_attachment(VI source) {
	const int N = source.size();
	static int callCount = 0;
	if (++callCount > callLimit(N)) {
		cerr << "too many calls of get_attachment() : " << callCount << endl;
		exit(1);
	}
	VI attachment = source;
	attachment.insert(attachment.end(), source.begin(), source.end());
	burnCpu(N*N);
	return attachment;
}

VI retrieve(VI data) {
	const int N = data.size()/3;
	static int callCount = 0;
	if (++callCount > callLimit(N)) {
		cerr << "too many calls of retrieve() : " << callCount << endl;
		exit(1);
	}
	VI result(N, 0);
	for (int i=0; i<N; i++)
		if (data[i]+data[N+i]+data[2*N+i] > 1)
			result[i] = 1;
	burnCpu(N*N);
	return result;
}
