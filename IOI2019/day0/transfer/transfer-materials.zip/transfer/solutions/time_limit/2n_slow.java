import java.util.Arrays;

/**
 * Suboptimal solution
 * K = 2*N
 * @author Kian Mirjalali
 *
 */
class transfer {
	
	private void burnCpu(int steps) {
		int temp = 0;
		for (int i=0; i<steps; i++)
			if (i*i+i == temp)
				temp++;
		if (temp == -1)
			System.err.println("impossible");
	}
	
	int[] get_attachment(int[] source) {
		final int N = source.length;
		int[] attachment = new int[2*N];
		System.arraycopy(source, 0, attachment, 0, N);
		System.arraycopy(source, 0, attachment, N, N);
		burnCpu(N*N);
		return attachment;
	}
	
	int[] retrieve(int[] data) {
		final int N = data.length/3;
		int[] result = new int[N];
		Arrays.fill(result, 0);
		for (int i=0; i<N; i++)
			if (data[i]+data[N+i]+data[2*N+i] > 1)
				result[i] = 1;
		burnCpu(N*N);
		return result;
	}
	
}
