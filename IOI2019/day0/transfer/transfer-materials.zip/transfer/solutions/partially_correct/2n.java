import java.util.Arrays;

/**
 * Suboptimal solution
 * K = 2*N
 * @author Kian Mirjalali
 *
 */
class transfer {
	
	private int callLimit(int N) {
		switch (N) {
		case 63:  return 20000;
		case 255: return 200000;
		}
		throw new Error("invalid value of N: "+N);
	}

	private static int callCount = 0;
	
	int[] get_attachment(int[] source) {
		final int N = source.length;
		if (++callCount > callLimit(N))
			throw new Error("too many calls of get_attachment() : "+callCount);
		int[] attachment = new int[2*N];
		System.arraycopy(source, 0, attachment, 0, N);
		System.arraycopy(source, 0, attachment, N, N);
		return attachment;
	}
	
	int[] retrieve(int[] data) {
		final int N = data.length/3;
		if (++callCount > callLimit(N))
			throw new Error("too many calls of retrieve() : "+callCount);
		int[] result = new int[N];
		Arrays.fill(result, 0);
		for (int i=0; i<N; i++)
			if (data[i]+data[N+i]+data[2*N+i] > 1)
				result[i] = 1;
		return result;
	}
	
}
