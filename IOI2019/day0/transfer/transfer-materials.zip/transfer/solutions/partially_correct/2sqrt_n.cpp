#include "transfer.h"
using namespace std;

//Author: Kian Mirjalali
//K = 2 sqrt{N}

typedef vector<int> VI;
#define fori(i,n) for (int i=0; i<(n); i++)

static int N, R, C;

inline void compRC() {
	C = 0;
	while (C*C < N)
		C++;
	R = N/C;
	while (R*C < N)
		R++;
}

static vector<VI> tab;
static VI rx, cx;

inline void fillx(const VI& source) {
	tab.clear();
	tab.resize(R, VI(C, -1));
	int t = 0;
	fori(i, R)
		fori(j, C)
			if (t < N)
				tab[i][j] = t++;
	rx.clear();
	rx.resize(R, 0);
	fori(i, R)
		fori(j, C)
			if (tab[i][j] >= 0)
				rx[i] ^= source[tab[i][j]];

	cx.clear();
	cx.resize(C, 0);
	fori(j, C)
		fori(i, R)
			if (tab[i][j] >= 0)
				cx[j] ^= source[tab[i][j]];
}

VI get_attachment(VI source) {
	N = source.size();
	compRC();
	fillx(source);
	VI attachment(rx);
	attachment.insert(attachment.end(), cx.begin(), cx.end());
	return attachment;
}

VI retrieve(VI data) {
	int ds = data.size();
	N = 0;
	do {
		N++;
		compRC();
	} while (N + R+C < ds);

	VI result(data.begin(), data.begin()+N);
	VI attachment(data.begin()+N, data.end());

	fillx(result);
	int br = -1;
	fori(i, R)
		if (attachment[i] != rx[i])
			br = i;
	int bc = -1;
	fori(j, C)
		if (attachment[R+j] != cx[j])
			bc = j;

	if (br != -1 && bc != -1)
		result[tab[br][bc]] ^= 1;

	return result;
}
