#include "transfer.h"
using namespace std;

//Author: Kian Mirjalali
//K = N+1

typedef vector<int> VI;

static inline int rangeXorVec(VI v, int begin, int end) {
	int s = 0;
	for (int i = begin; i < end; i++)
		s ^= v[i];
	return s;
}

VI get_attachment(VI source) {
	const int N = source.size();
	VI attachment = source;
	attachment.push_back(rangeXorVec(source, 0, N));
	return attachment;
}

VI retrieve(VI data) {
	const int N = (data.size()-1)/2;
	VI result(data.begin(), data.begin()+N);
	int s = 0;
	for (int b : result)
		s ^= b;
	if (s == data.back())
		return result;
	return VI(data.begin()+N, data.begin()+(2*N));
}
