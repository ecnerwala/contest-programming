import java.util.Arrays;

/**
 * Suboptimal solution
 * K = 2 sqrt{N}
 * @author Kian Mirjalali
 *
 */
class transfer {
	
	private int N, R, C;

	private void compRC() {
		C = 0;
		while (C*C < N)
			C++;
		R = N/C;
		while (R*C < N)
			R++;
	}

	private int[][] tab;
	private int[] rx, cx;

	private void fillx(int[] source) {
		tab = new int[R][C];
		for (int[] row : tab)
			Arrays.fill(row, -1);
		int t = 0;
		for (int i=0; i<R; i++)
			for (int j=0; j<C; j++)
				if (t < N)
					tab[i][j] = t++;
		rx = new int[R];
		Arrays.fill(rx, 0);
		for (int i=0; i<R; i++)
			for (int j=0; j<C; j++)
				if (tab[i][j] >= 0)
					rx[i] ^= source[tab[i][j]];

		cx = new int[C];
		Arrays.fill(cx, 0);
		for (int j=0; j<C; j++)
			for (int i=0; i<R; i++)
				if (tab[i][j] >= 0)
					cx[j] ^= source[tab[i][j]];
	}
	
	
	int[] get_attachment(int[] source) {
		N = source.length;
		compRC();
		fillx(source);
		int[] attachment = new int[R+C];
		System.arraycopy(rx, 0, attachment, 0, R);
		System.arraycopy(cx, 0, attachment, R, C);
		return attachment;
	}
	
	int[] retrieve(int[] data) {
		int ds = data.length;
		N = 0;
		do {
			N++;
			compRC();
		} while (N + R+C < ds);

		int[] result = Arrays.copyOfRange(data, 0, N);
		int[] attachment = Arrays.copyOfRange(data, N, data.length);

		fillx(result);
		int br = -1;
		for (int i=0; i<R; i++)
			if (attachment[i] != rx[i])
				br = i;
		int bc = -1;
		for (int j=0; j<C; j++)
			if (attachment[R+j] != cx[j])
				bc = j;

		if (br != -1 && bc != -1)
			result[tab[br][bc]] ^= 1;

		return result;
	}
	
}
