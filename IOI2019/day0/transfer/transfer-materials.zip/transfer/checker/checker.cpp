#include "testlib.h"
using namespace std;

const string output_secret = "bbda7722-086a-420f-811f-e3648ef86a25";

NORETURN void qp60(int grade) {
  quitp(grade/double(60));
}
NORETURN void qp40(int grade) {
  quitp(grade/double(40));
}

int main(int argc, char * argv[])
{
	registerChecker("transfer", argc, argv);

	inf.readLine();//input_secret
	string main_source = inf.readLine();
	int N = main_source.size();
	int num_attachments = N+1;

	ouf.readSecret(output_secret);
	ouf.readGraderResult();
	int Q = 0;
	for (int i=0; i<num_attachments; i++) {
		int K = ouf.readInt();
		if (Q < K)
			Q = K;
	}

	switch (N) {
	case 63: //Subtask 1
		if (126 < Q)	qp60(0);
		if (64 < Q)		qp60(3);
		if (40 < Q)		qp60(9);
		if (20 < Q) 	qp60(18);
		if (16 < Q) 	qp60(30);
		if (12 < Q) 	qp60(36);
		if (7 < Q)  	qp60(48);
		// Q <= 9
		quit(_ok);
		break;
	case 255: //Subtask 2
		if (510 < Q)	qp40(0);
		if (256 < Q)	qp40(2);
		if (140 < Q)	qp40(6);
		if (35 < Q) 	qp40(12);
		if (32 < Q) 	qp40(20);
		if (16 < Q) 	qp40(24);
		if (9 < Q)  	qp40(32);
		// Q <= 9
		quit(_ok);
		break;
	default:
		quitf(_fail, "invalid value of N: %d", N);
	}
	return 0;
}
