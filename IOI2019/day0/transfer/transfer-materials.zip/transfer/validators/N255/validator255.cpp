const int N = 255;
#include "validator.h"
