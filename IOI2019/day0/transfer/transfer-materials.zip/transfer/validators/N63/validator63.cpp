const int N = 63;
#include "validator.h"
