import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Random;

/**
 * Judge grader
 * @author Kian Mirjalali
 *
 */
public class grader {

	private static <T> void shuffle(List<T> v){
		Random rnd = new Random(3532);
		int n = v.size();
		for(int i = n-1; i > 0; i--){
			int j = rnd.nextInt(i+1);
			T tmp = v.get(i);
			v.set(i, v.get(j));
			v.set(j, tmp);
		}
	}
	
	private static void close(Closeable c) {
		try {
			c.close();
		} catch (IOException e) {
			//Do nothing
		}
	}
	
	private static class GraderException extends Exception {
		private static final long serialVersionUID = 1L;
		
		private String msg;
		private String reason;
		
		public GraderException(String msg, String reason) {
			this.msg = msg; 
			this.reason = reason;
		}
		public GraderException(String msg) {
			this(msg, "");
		}
		
		public void eject(PrintWriter pw, String secret) {
			pw.println(secret);
			pw.println(this.msg);
			pw.println(this.reason);
			close(pw);
			System.exit(0);
		}
	}
	

	private static String vi2str(int[] v, String prefix) {
		String s = prefix;
		for (int x : v)
			s += (char)(((int)'0')+x);
		return s;
	}
	private static String vi2str(int[] v) {
		return vi2str(v, "");
	}

	private static int[] str2vi(String s) {
		int[] v = new int[s.length()];
		for (int i = 0; i < s.length(); i++)
			v[i] = (int)(s.charAt(i)-'0');
		return v;
	}

	private static int[] str2vi(String s, String prefix) throws GraderException {
		if (!s.startsWith(prefix))
			throw new GraderException("FAIL", "expected prefix not found: "+prefix);
		return str2vi(s.substring(prefix.length()));
	}

	private static void toggle(int[] v, int index) {
		v[index] = 1 - v[index];
	}

	
	private static class SourceAndAttachment {
		private static final String attachment_prefix = "A";
		
		public int[] source;
		public int[] attachment;
		
		public SourceAndAttachment(int[] source) {
			this.source = source;
		}
		
		public SourceAndAttachment(InputReader pipe2) throws GraderException {
			String source_str = pipe2.readString();
			String attachment_str = pipe2.readString();
			this.source = str2vi(source_str);
			this.attachment = str2vi(attachment_str, attachment_prefix);
		}
		
		void write(PrintWriter pipe1) {
			pipe1.println(vi2str(source)+" "+ vi2str(attachment, attachment_prefix));
		}
		
	}
	
	
	@SuppressWarnings("resource")
	private void pass1(String pipe_path) {
		final String input_secret = "3fde153a-2d9e-4cab-aaed-47175facae96";
		final String pipe_secret = "aad8b291-f7c9-4935-ac07-3f34523a67ab";
		PrintWriter pipe1 = null;
		try {
			pipe1 = new PrintWriter(new File(pipe_path));
		} catch (FileNotFoundException e) {
			e.printStackTrace(System.err);
			System.exit(1);
		}
		try {
			close(System.out);
			
			int N;
			SourceAndAttachment[] sourceAndAttachments;
			//reading input
			try (InputReader inputReader = new InputReader(System.in)) {
				String secret = inputReader.readString();
				if (!input_secret.equals(secret))
					throw new GraderException("SV");
				
				String main_source_str = inputReader.readString();
				int[] main_source = str2vi(main_source_str);
				N = main_source.length;
				
				sourceAndAttachments = new SourceAndAttachment[N+1];
				int h = 0;
				sourceAndAttachments[h++] = new SourceAndAttachment(main_source);
				for (int i=0; i<N; i++) {
					int[] source = main_source.clone();//full copy
					toggle(source, i);
					sourceAndAttachments[h++] = new SourceAndAttachment(source);
				}
			}
			
			final int attachment_size_limit = 2*N;
			transfer solver = new transfer();
			
			for (SourceAndAttachment saa : sourceAndAttachments) {
				int[] given_source = saa.source.clone();//full copy
				int[] attachment = solver.get_attachment(given_source);
				if (attachment.length > attachment_size_limit)
					throw new GraderException("WA", "attachment too large");
				for (int x : attachment)
					if (x != 0 && x != 1)
						throw new GraderException("WA", "invalid attachment integer value");
				saa.attachment = attachment.clone();//full copy
			}
			
			{//writing intermediate data
				pipe1.println(pipe_secret);
				pipe1.println("OK");
				pipe1.println(sourceAndAttachments.length);
				for (SourceAndAttachment saa : sourceAndAttachments)
					saa.write(pipe1);
				close(pipe1);
			}
		} catch (GraderException e) {
			e.eject(pipe1, pipe_secret);
		}
	}

	private static class Scenario {
		int sourceAndAttachmentIndex;
		int dataCorruptionIndex; // (-1 for no corruption)
		public Scenario(int sourceAndAttachmentIndex, int dataCorruptionIndex) {
			this.sourceAndAttachmentIndex = sourceAndAttachmentIndex;
			this.dataCorruptionIndex = dataCorruptionIndex;
		}
	}
	
	private void pass2(String pipe_path) {
		final String pipe_secret = "aad8b291-f7c9-4935-ac07-3f34523a67ab";
		final String output_secret = "bbda7722-086a-420f-811f-e3648ef86a25";
		try {
			close(System.in);
			SourceAndAttachment[] sourceAndAttachments = null;
			//reading intermediate data
			try (InputReader pipe2 = new InputReader(new FileInputStream(pipe_path))) {
				String secret = pipe2.readString();
				if (!pipe_secret.equals(secret))
					throw new GraderException("SV");

				String status = pipe2.readString();
				if (!"OK".equals(status)) {
					String reason = pipe2.readLine();
					throw new GraderException(status, reason);
				}
				
				int n_saa = pipe2.readInt();
				sourceAndAttachments = new SourceAndAttachment[n_saa];
				for (int i=0; i<n_saa; i++)
					sourceAndAttachments[i] = new SourceAndAttachment(pipe2);
			} catch (FileNotFoundException e) {
				throw new GraderException("FAIL", "pipe not found: "+pipe_path);
			}
			
			List<Scenario> scenarios = new ArrayList<>();
			for (int i=0; i<sourceAndAttachments.length; i++) {
				int N = sourceAndAttachments[i].source.length;
				int K = sourceAndAttachments[i].attachment.length;
				for (int j=-1; j<N+K; j++)
					scenarios.add(new Scenario(i, j));
			}

			shuffle(scenarios);
			
			transfer solver = new transfer();
			for (Scenario scenario : scenarios) {
				int[] initial_source = sourceAndAttachments[scenario.sourceAndAttachmentIndex].source;
				int[] attachment = sourceAndAttachments[scenario.sourceAndAttachmentIndex].attachment;
				int[] data = new int[initial_source.length+attachment.length];
				System.arraycopy(initial_source, 0, data, 0, initial_source.length);
				System.arraycopy(attachment, 0, data, initial_source.length, attachment.length);
				if (scenario.dataCorruptionIndex >= 0)
					toggle(data, scenario.dataCorruptionIndex);
				int[] result_source = solver.retrieve(data);
				if (!Arrays.equals(initial_source, result_source)) {
					System.err.println("initial source:");
					System.err.println(vi2str(initial_source));
					System.err.println("attachment:");
					System.err.println(vi2str(attachment));
					System.err.println("data corruption index: "+scenario.dataCorruptionIndex);
					System.err.println("result source:");
					System.err.println(vi2str(result_source));
					throw new GraderException("WA", "wrong source retrieval");
				}
			}
			
			{//writing output
				System.out.println(output_secret);
				System.out.println("OK");
				for (SourceAndAttachment saa : sourceAndAttachments)
					System.out.println(saa.attachment.length);
				close(System.out);
			}
		} catch (GraderException e) {
			e.eject(new PrintWriter(System.out), output_secret);
		}
	}

	public static void main(String[] args) {
		if (args.length < 2) {
			System.out.println("invalid arguments");
			System.exit(1);
		}
		int type =  Integer.parseInt(args[0]);
		if (type == 0) {
			new grader().pass1(args[1]);
		} else {
			new grader().pass2(args[1]);
		}
	}
	
}


class InputReader implements java.io.Closeable {
	private java.io.InputStream stream;
	private byte[] buf = new byte[1024];
	private int curChar;
	private int numChars;

	public InputReader(java.io.InputStream stream) {
		this.stream = stream;
	}
	
	@Override
	public void close() {
		try {
			this.stream.close();
		} catch (java.io.IOException e) {
		}
	}

	public int read() {
		if (numChars == -1) {
			throw new java.util.InputMismatchException();
		}
		if (curChar >= numChars) {
			curChar = 0;
			try {
				numChars = stream.read(buf);
			} catch (java.io.IOException e) {
				throw new java.util.InputMismatchException();
			}
			if (numChars <= 0) {
				return -1;
			}
		}
		return buf[curChar++];
	}

	public int readInt() {
		int c = eatWhite();
		int sgn = 1;
		if (c == '-') {
			sgn = -1;
			c = read();
		}
		int res = 0;
		do {
			if (c < '0' || c > '9') {
				throw new java.util.InputMismatchException();
			}
			res *= 10;
			res += c - '0';
			c = read();
		} while (!isSpaceChar(c));
		return res * sgn;
	}

	public String readString() {
		int c = eatWhite();
		StringBuilder res = new StringBuilder();
		do {
			if (Character.isValidCodePoint(c))
				res.appendCodePoint(c);
			c = read();
		} while (!isSpaceChar(c));
		return res.toString();
	}

	public String readLine() {
		StringBuilder res = new StringBuilder();
		while (true) {
			int c = read();
			if (c == '\n' || c == '\r' || c == -1)
				break;
			if (Character.isValidCodePoint(c))
				res.appendCodePoint(c);
		}
		return res.toString();
	}

	private int eatWhite() {
		int c = read();
		while (isSpaceChar(c)) {
			c = read();
		}
		return c;
	}

	public static boolean isSpaceChar(int c) {
		return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
	}
}
