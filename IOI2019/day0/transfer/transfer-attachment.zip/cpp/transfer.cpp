#include "transfer.h"

std::vector<int> get_attachment(std::vector<int> source) {
	return { 0, 1, 0 };
}

std::vector<int> retrieve(std::vector<int> data) {
	return std::vector<int>(data.begin(), data.end()-3);
}
