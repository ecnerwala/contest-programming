#include "bits/stdc++.h"
#include "cycle.h"

using namespace std;

void escape(int n) {
	int p = n/4+1;
	bool check = jump(0);
	while(p) {
		check = jump(check ? p : (n-p)%n);
		p /= 2;
	}
	if(!check) jump(n-1);
}
