#include "bits/stdc++.h"
#include "cycle.h"

using namespace std;

void escape(int n) {
  bool check = jump(0);
  for(int i=0; i<n; i++) if(jump(1) != check) break;
  jump(check ? n-1 : n/2);
}
