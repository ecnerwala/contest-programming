class cycle {
	public void escape(int n) {
		int p = (n/4)+1;
    boolean check = grader.jump(0);
    while(p > 0) {
      check = grader.jump(check ? p : (n-p)%n);
      p = (p == 1 ? 0 : (p+1)/2);
    }
    if(!check) grader.jump(n-1);
	}
}
