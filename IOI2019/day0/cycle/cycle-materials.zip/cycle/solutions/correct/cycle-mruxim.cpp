#include "cycle.h"
#include <vector>
#include <set>

using namespace std;

void escape(int n) {
	bool c = jump(0);
	int p = n/4 + 1;
	do {
		if(c) c = jump(p);
		else c = jump(n-p);
		p = p / 2 + ((p % 2) & (p > 1));
	} while(p >= 1);
	if(!c) jump(n-1);
	jump(0);
}
