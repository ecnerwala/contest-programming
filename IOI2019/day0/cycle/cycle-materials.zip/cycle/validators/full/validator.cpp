#include "testlib.h"

using namespace std;

const int maxn = 1000000000;

int main() {
	registerValidation();

	string secret = inf.readLine();
	ensuref(secret == (string)"3f130aac-d629-40d9-b3ad-b75ea9aa8052", "Secret not found!");

	int n = inf.readInt(1, maxn, "n");
	inf.readSpace();
	inf.readInt(1, n-1, "p");
	inf.readEoln();
	inf.readEof();
	return 0;
}
