
public class grader {

	private static final int cnt_lim = 35;
	private static int n, p, cnt;

	private static void wrong_answer(String reason) {
		// BEGIN SECRET
		final String output_secret = "f3697e79-76f0-4a15-8dc8-212253e98c61";
		System.out.println(output_secret);
		System.out.println("WA");
		// END SECRET
		System.out.println(reason);
		System.out.close();
		System.exit(0);
	}

	public static boolean jump(int x) {
		if (x < 0 || x >= n)
			wrong_answer("Invalid argument.");
		cnt++;
		if (cnt > cnt_lim)
			wrong_answer("Too many queries.");

		p = (p + x) % n;
		return (n - p) % n <= n / 2;
	}

	static void run() {
		try (InputReader inputReader = new InputReader(System.in)) {
			// BEGIN SECRET
			final String input_secret = "3f130aac-d629-40d9-b3ad-b75ea9aa8052";
			String secret = inputReader.readString();
			if (!input_secret.equals(secret)) {
				final String output_secret = "f3697e79-76f0-4a15-8dc8-212253e98c61";
				System.out.println(output_secret);
				System.out.println("SV");
				System.out.close();
				System.exit(0);
			}
			// END SECRET
			n = inputReader.readInt();
			p = inputReader.readInt();
		}

		cnt = 0;
		cycle solver = new cycle();
		solver.escape(n);
		if (p != 0)
			wrong_answer("The exit was not found.");

		// BEGIN SECRET
		final String output_secret = "f3697e79-76f0-4a15-8dc8-212253e98c61";
		System.out.println(output_secret);
		// END SECRET
		System.out.println("OK");
		System.err.println(cnt);
		System.out.close();
	}

	public static void main(String[] args) {
		grader.run();
	}
}


class InputReader implements java.io.Closeable {
	private java.io.InputStream stream;
	private byte[] buf = new byte[1024];
	private int curChar;
	private int numChars;

	public InputReader(java.io.InputStream stream) {
		this.stream = stream;
	}

	@Override
	public void close() {
		try {
			this.stream.close();
		} catch (java.io.IOException e) {
		}
	}

	public int read() {
		if (numChars == -1) {
			throw new java.util.InputMismatchException();
		}
		if (curChar >= numChars) {
			curChar = 0;
			try {
				numChars = stream.read(buf);
			} catch (java.io.IOException e) {
				throw new java.util.InputMismatchException();
			}
			if (numChars <= 0) {
				return -1;
			}
		}
		return buf[curChar++];
	}

	public int readInt() {
		int c = eatWhite();
		int sgn = 1;
		if (c == '-') {
			sgn = -1;
			c = read();
		}
		int res = 0;
		do {
			if (c < '0' || c > '9') {
				throw new java.util.InputMismatchException();
			}
			res *= 10;
			res += c - '0';
			c = read();
		} while (!isSpaceChar(c));
		return res * sgn;
	}

	public String readString() {
		int c = eatWhite();
		StringBuilder res = new StringBuilder();
		do {
			if (Character.isValidCodePoint(c))
				res.appendCodePoint(c);
			c = read();
		} while (!isSpaceChar(c));
		return res.toString();
	}

	public String readLine() {
		StringBuilder res = new StringBuilder();
		while (true) {
			int c = read();
			if (c == '\n' || c == '\r' || c == -1)
				break;
			if (Character.isValidCodePoint(c))
				res.appendCodePoint(c);
		}
		return res.toString();
	}

	private int eatWhite() {
		int c = read();
		while (isSpaceChar(c)) {
			c = read();
		}
		return c;
	}

	public static boolean isSpaceChar(int c) {
		return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
	}
}
