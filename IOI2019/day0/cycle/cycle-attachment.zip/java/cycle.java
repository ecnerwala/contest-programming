class cycle {
	public void escape(int n) {
		if(n == 10) {
			if(grader.jump(3) == true) {
				grader.jump(2);
				grader.jump(3);
				grader.jump(1);
				grader.jump(6);
			}
		}
	}
}
