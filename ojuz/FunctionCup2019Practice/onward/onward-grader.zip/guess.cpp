#include "guess.h"

std::string GuessWord(int M, std::string YH){
	return YH;
}
