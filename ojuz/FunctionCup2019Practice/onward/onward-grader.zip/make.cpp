#include "make.h"

std::string MakeWord(int N, int M, std::vector<std::string> Dict) {
	return Dict[0];
}
