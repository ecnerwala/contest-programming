#include "squad.h"

void Init(std::vector<int> A, std::vector<int> D, std::vector<int> P){
	int N = A.size();
}

long long BestSquad(int X, int Y){
	return 0;
}
