#include "lokahia.h"

int FindBase(int N){
	CollectRelics(0, 2);
	CollectRelics(1, 3);
	CollectRelics(2, 4);
	return 3;
}
