#include <bits/stdc++.h>
using namespace std;

const int DAY = 24 * 60;

const bool digits[10][7] = {
//   0,1,2,3,4,5,6
	{1,1,1,0,1,1,1}, // 0
	{0,0,1,0,0,1,0}, // 1
	{1,0,1,1,1,0,1}, // 2
	{1,0,1,1,0,1,1}, // 3
	{0,1,1,1,0,1,0}, // 4
	{1,1,0,1,0,1,1}, // 5
	{1,1,0,1,1,1,1}, // 6
	{1,0,1,0,0,1,0}, // 7
	{1,1,1,1,1,1,1}, // 8
	{1,1,1,1,0,1,1}, // 9
};
const int pos[7][2][2] = {
	{{0, 1}, {0, 2}},
	{{1, 0}, {2, 0}},
	{{1, 3}, {2, 3}},
	{{3, 1}, {3, 2}},
	{{4, 0}, {5, 0}},
	{{4, 3}, {5, 3}},
	{{6, 1}, {6, 2}}
};

void print(bool a[10][30]) {
	for(int r = 0; r < 7; r++) {
		for(int c = 0; c < 21; c++) {
			cerr << char(a[r][c] ? 'X' : '.');
		}
		cerr << '\n';
	}
	cerr << '\n';
}

char buf[30];

const int MAXN = 200;
int N;

bool disp[MAXN][10][30];

bool has[10][30][2];
bool might_work[10][30];

bool cur_disp[10][30];
bool matches[10][30];

void get_dig(int d, int c0) {
	assert(0 <= d && d < 10);
	for(int seg = 0; seg < 7; seg++) {
		if(digits[d][seg]) {
			for(int z = 0; z < 2; z++) {
				cur_disp[pos[seg][z][0]][pos[seg][z][1] + c0] = true;
			}
		}
	}
}

void get_time(int h, int m) {
	int a = h / 10, b = h % 10;
	int c = m / 10, d = m % 10;

	memset(cur_disp, 0, sizeof(cur_disp));

	// colons
	cur_disp[2][10] = true;
	cur_disp[4][10] = true;

	if(a) get_dig(a, 0);
	get_dig(b, 5);
	get_dig(c, 12);
	get_dig(d, 17);
}

int main() {
	// input
	ios_base::sync_with_stdio(0);
	cin >> N;
	for(int i = 0; i < N; i++) {
		for(int r = 0; r < 7; r++) {
			cin >> buf;
			for(int c = 0; c < 21; c++) {
				if(buf[c] == 'X') disp[i][r][c] = true;
				else if(buf[c] == '.') disp[i][r][c] = false;
				else assert(false);
			}
		}
	}

	// populate has
	for(int i = 0; i < N; i++) {
		for(int r = 0; r < 7; r++) {
			for(int c = 0; c < 21; c++) {
				has[r][c][disp[i][r][c]] = true;
			}
		}
	}

	bool impossible = true;
	for(int t = 0; t < DAY; t++) {
		for(int r = 0; r < 7; r++) {
			for(int c = 0; c < 21; c++) {
				matches[r][c] = true;
			}
		}
		for(int i = 0; i < N; i++) {
			get_time((t + i) / 60 % 24, (t + i) % 60);
			for(int r = 0; r < 7; r++) {
				for(int c = 0; c < 21; c++) {
					if(cur_disp[r][c] != disp[i][r][c]) matches[r][c] = false;
				}
			}
		}
		bool is_good = true;
		for(int r = 0; r < 7; r++) {
			for(int c = 0; c < 21; c++) {
				if(has[r][c][0] && has[r][c][1]) {
					if(!matches[r][c]) is_good = false;
				}
			}
		}
		if(is_good) {
			impossible = false;
			for(int r = 0; r < 7; r++) {
				for(int c = 0; c < 21; c++) {
					if(matches[r][c]) might_work[r][c] = true;
				}
			}
		}
	}

	if(impossible) {
		 cout << "impossible" << '\n';
	} else {
		get_time(88, 88);
		for(int r = 0; r < 7; r++) {
			for(int c = 0; c < 21; c++) {
				if(cur_disp[r][c]) {
					assert(has[r][c][0] || has[r][c][1]);
					if(has[r][c][0] && has[r][c][1]) {
						assert(might_work[r][c]);
						cout << 'W';
					} else if(might_work[r][c]) {
						cout << '?';
					} else if(has[r][c][0]) {
						cout << '0';
					} else if(has[r][c][1]) {
						cout << '1';
					} else assert(false);
				} else {
					cout << '.';
				}
			}
			cout << '\n';
		}
	}

}
