#include<bits/stdc++.h>
using namespace std;

const int MAXN = 60;
const int MAXK = 30;

const int MAXV = MAXN * MAXK;

int N, K;
vector<int> roots;

int V;
int val[MAXV];
int ch[MAXV][2];

bool matches(int a, int b) {
	if(a == 0 && b == 0) return true;
	if(a == 0 || b == 0) return false;
	return matches(ch[a][0], ch[b][0]) && matches(ch[a][1], ch[b][1]);
}

int main() {
	V = 1;
	ios_base::sync_with_stdio(0);
	cin >> N >> K;
	memset(ch, 0, sizeof(ch));
	for(int i = 0; i < N; i++) {
		// first build the tree
		cin >> val[V];
		int r = V;
		V++;
		for(int j = 1; j < K; j++) {
			cin >> val[V];
			int cur = r;
			while(true) {
				int d = (val[V] < val[cur]);
				if(ch[cur][d]) {
					cur = ch[cur][d];
				} else {
					ch[cur][d] = V;
					V++;
					break;
				}
			}
		}
		bool is_new = true;
		for(int other : roots) {
			if(matches(other, r)) {
				//cerr << other / K << ' ' << r / K << '\n';
				is_new = false;
				break;
			}
		}
		if(is_new) roots.push_back(r);
	}
	cout << int(roots.size()) << '\n';
}
