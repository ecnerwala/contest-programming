#include<bits/stdc++.h>
using namespace std;

inline void wssert(bool b) { if(!b) exit(0); }

typedef long long ll;
typedef long double ld;

ll Y, L;

bool is_good(ll b) {
	wssert(b >= 10);
	ll val = 0;
	for(ll p10 = 1, v = Y; v; v /= b, p10 *= 10) {
		ll d = v % b;
		if(d >= 10) return false;
		val += d * p10;
		wssert(val >= 0);
	}
	wssert(val >= 0);
	return val >= L;
}

ll go() {
	ll res = 10;
	for(ll b = 10; b <= ll(2e6); b++) {
		if(is_good(b)) {
			res = max(res, b);
		}
	}

	for(ll v = L; v < 1000; v++) {
		ll a = v / 100, b = v / 10 % 10, c = v % 10;
		wssert(Y >= 10);
		wssert(c < 10);
		wssert(Y > c);
		if(a == 0) {
			wssert(v >= 10);
			wssert(b > 0);
			if((Y - c) % b == 0) {
				res = max(res, (Y - c) / b);
			}
		} else {
			ld x = (Y - c);
			x *= 4 * a;
			x += b * b;
			x = sqrt(x);
			x -= b;
			x /= 2 * a;
			ll base = ll(round(x));
			if(base >= 10 && Y % base == c && Y / base % base == b && Y / base / base == a) {
				res = max(res, base);
			}
		}
	}
	return res;
}

int main() {
	cin >> Y >> L;
	cout << go() << '\n';
}
