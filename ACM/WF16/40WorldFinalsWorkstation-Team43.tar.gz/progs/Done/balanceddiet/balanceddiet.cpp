#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

struct frac {
	ll n, d;
	
	frac(ll num, ll den) : n(num), d(den) {
		assert(d);
		if(d < 0) {
			n *= -1;
			d *= -1;
		}
		assert(d > 0);
	}

	frac(ll v) : frac(v, 1) {}

	frac() : frac(0) {}
};

bool operator < (const frac &a, const frac &b) {
	assert(a.d > 0);
	assert(b.d > 0);
	return a.n * b.d < b.n * a.d;
}

const int MAXM = 2e5;
const int MAXK = 2e5;
int M, K;

ll A[MAXM];
ll S;

ll B[MAXK];

ll cur[MAXM];

ll ceil(ll a, ll b) {
	return (a + b - 1) / b;
}

ll death(int i) {
	return ceil(S * (cur[i] + 1), A[i]);
}

ll go() {
	priority_queue<pair<ll, int>> pq; // max queue, so death times are negated

	for(int i = 0; i < M; i++) {
		pq.emplace(-death(i), i);
	}

	for(int t = K + 1; t <= MAXK * 2; t++) {
		assert(!pq.empty());

		assert(-pq.top().first >= t);
		int i = pq.top().second;
		pq.pop();
		cur[i] ++;
		//cerr << "pushing" << death(i) << ' ' << i << '\n';
		pq.emplace(-death(i), i);
		if(-pq.top().first <= t) {
			return t - 1;
		}
	}

	return -1;
}

int main() {
	ios_base::sync_with_stdio(0);
	cin >> M >> K;
	S = 0;
	for(int i = 0; i < M; i++) {
		cin >> A[i];
		S += A[i];
	}
	memset(cur, 0, sizeof(cur));
	for(int i = 0; i < K; i++) {
		cin >> B[i];
		B[i] --;
		cur[B[i]] ++;
	}

	ll res = go();
	if(res >= 0) {
		cout << res - K << '\n';
	} else {
		cout << "forever" << '\n';
	}

}
