#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

typedef pair<ll, ll> pii;
#define A first
#define B second

struct frac {
	ll n, d;
	frac() : n(0ll), d(1ll) {}
	frac(ll num, ll den) : n(num), d(den) {
		assert(d);
		if(d < 0) {
			d *= -1;
			n *= -1;
		}
		assert(d > 0);
	}
};

bool operator < (const frac &a, const frac &b) {
	assert(a.d > 0);
	assert(b.d > 0);
	return a.n * b.d < b.n * a.d;
}

const int MAXN = 2e3;
int N;
ll X[MAXN][2];
ll Y[MAXN];
ll V[MAXN];

int main() {
	ios_base::sync_with_stdio(0);
	cin >> N;
	for(int i = 0; i < N; i++) {
		cin >> X[i][0] >> X[i][1] >> Y[i];
		if(X[i][0] > X[i][1]) swap(X[i][0], X[i][1]);
		assert(X[i][0] <= X[i][1]);
		V[i] = X[i][1] - X[i][0];
		assert(V[i] >= 0);
	}

	ll res = 0;
	for(int i = 0; i < N; i++) {
		res = max(res, V[i]);
	}

	for(int z = 0; z < N; z++) {
		for(int d =- 0; d < 2; d++) {
			ll x = X[z][d], y = Y[z], v = V[z];
			vector<pair<frac, ll>> vec;
			for(int i = 0; i < N; i++) {
				if(Y[i] == y) continue;
				frac l(X[i][0] - x, Y[i] - y);
				frac r(X[i][1] - x, Y[i] - y);
				if(r < l) swap(l, r);
				assert(!(r < l)); // assert(l <= r);
				vec.emplace_back(l, -V[i]);
				vec.emplace_back(r, V[i]);
			}
			sort(vec.begin(), vec.end());
			reverse(vec.begin(), vec.end());
			for(auto it : vec) {
				v += it.second;
				assert(v >= 0);
				res = max(res, v);
			}
		}
	}
	cout << res << '\n';
}
