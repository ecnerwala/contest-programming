#include <bits/stdc++.h>
using namespace std;
#define fori(i,s,e) for(int i = s; i < ((int)e); i++)

int n;
deque<int> master;
deque<int> q;

bool ripFront(int m) {
	if (!q.size()) return false;
	if (q.front() < m) return false;
	q.front() -= m;
	if (q.front() == 0) q.pop_front();
	return true;
}
bool ripBack(int m) {
	if (!q.size()) return false;
	if (q.back() < m) return false;
	q.back() -= m;
	if (q.back() == 0) q.pop_back();
	return true;
}
bool check(int qlevel) {
	q = master;
	for(int m = qlevel; m >= 1; m--) {
		if (!ripFront(m)) return false;
		if (!ripBack(m)) return false;
	}
	return true;
}
int tot;
int solve() {
	if (tot % 2) return 0;
	for (int ql = 100; ql >= 2; ql--) {
		if (check(ql)) return ql;
	}
	if (tot == 2) return 1;
	return 0;
}

int main() {
	ios::sync_with_stdio(0);
	cin >> n;

	tot = 0;
	fori (i, 0, n) {
		int x;
		cin >> x;
		master.push_back(x);
		tot += x;
		// check even!!
	}
	int ans = solve();
	if (ans) {
		cout << ans << "\n";
	} else {
		cout << "no quotation\n";
	}
}
