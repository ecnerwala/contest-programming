#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

typedef pair<ll, ll> pii;
#define A first
#define B second

ll N;

vector<pii> incr;
ll max_same;
vector<pii> decr;

int main() {
	ios_base::sync_with_stdio(0);
	cin >> N;
	max_same = 0;
	for(ll i = 0; i < N; i++) {
		ll a, b; cin >> a >> b;
		if(a == b) {
			max_same = max(max_same, a);
		} else if(a < b) {
			incr.emplace_back(a, b);
		} else {
			decr.emplace_back(b, a);
		}
	}
	sort(incr.begin(), incr.end());
	sort(decr.begin(), decr.end());
	reverse(decr.begin(), decr.end());
	ll res = 0;
	ll free = 0;

	for(pii p : incr) {
		//cerr << p.A << ' ' << p.B << '\n';
		if(free < p.A) {
			ll diff = p.A - free;
			free += diff;
			res += diff;
		}
		assert(free >= p.A);
		free -= p.A;
		free += p.B;
	}

	if(free < max_same) {
		ll diff = max_same - free;
		free += diff;
		res += diff;
	}

	for(pii p : decr) {
		swap(p.A, p.B);
		//cerr << p.A << ' ' << p.B << '\n';
		if(free < p.A) {
			ll diff = p.A - free;
			free += diff;
			res += diff;
		}
		assert(free >= p.A);
		free -= p.A;
		free += p.B;
	}

	assert(free >= 0);
	cout << res << '\n';
}
