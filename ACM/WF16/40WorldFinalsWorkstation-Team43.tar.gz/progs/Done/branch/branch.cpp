#include<bits/stdc++.h>
using namespace std;

typedef long long ll;

const ll INF = 2e18;

const int MAXN = 6000;
const int MAXB = MAXN;
const int MAXS = MAXB;

int N, B, S, R;

ll dist[2][MAXN];

ll val[MAXB];

vector<pair<ll, int>> adj[2][MAXN];

ll dp[MAXB][MAXS];

ll go() {
	for(int i = 0; i < B; i++) {
		val[i] = dist[0][i] + dist[1][i];
	}
	//for(int i = 0; i < B; i++) { cerr << val[i] << ' '; } cerr << '\n';
	sort(val, val + B);
	//for(int i = 0; i < B; i++) { cerr << val[i] << ' '; } cerr << '\n';
	memset(dp, 0, sizeof(dp));
	for(ll pref = 1; pref <= B; pref++) {
		dp[pref][0] = INF;
		for(ll gr = 1; gr <= S && gr <= pref; gr++) {
			ll v = INF;
			ll sum = 0;
			for(ll i = 1; i <= pref / gr; i++) {
				sum += val[pref - i];
				v = min(v, sum * (i - 1) + dp[pref - i][gr - 1]);
			}
			dp[pref][gr] = v;
		}
	}
	return dp[B][S];
}

int main() {
	ios_base::sync_with_stdio(0);
	cin >> N >> B >> S >> R;
	for(int i = 0; i < R; i++) {
		int u, v;
		ll l;
		cin >> u >> v >> l;
		u--, v--;
		adj[0][u].emplace_back(l, v);
		adj[1][v].emplace_back(l, u);
	}

	for(int z = 0; z < 2; z++) {
		for(int i = 0; i < N; i++) {
			dist[z][i] = INF;
		}

		dist[z][B] = 0;
		priority_queue<pair<ll, int>> pq;
		pq.emplace(dist[z][B], B);

		while(!pq.empty()) {
			int cur = pq.top().second;
			ll d = -pq.top().first;
			pq.pop();
			assert(d >= dist[z][cur]);
			if(d > dist[z][cur]) continue;
			assert(d == dist[z][cur]);

			for(auto n : adj[z][cur]) {
				n.first += d;
				if(n.first < dist[z][n.second]) {
					dist[z][n.second] = n.first;
					pq.emplace(-dist[z][n.second], n.second);
				}
			}

		}
	}

	cout << go() << '\n';
}
