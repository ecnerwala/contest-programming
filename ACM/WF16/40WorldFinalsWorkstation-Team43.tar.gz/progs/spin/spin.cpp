#include<bits/stdc++.h>
using namespace std;

#define fori(i,s,e) for(int i = s; i < ((int)e); i++)
#define allof(x) (x).begin(), (x).end()
typedef long long ll;
typedef double ld;

inline ll sign(ll a) {
	if(a == 0) return 0;
	else return (a < 0) ? -1 : 1;
}

template<typename T> void minify(T & a, const T & b) {
	if (a > b) a = b;
}

struct Pt {
	ll x, y;
	Pt(): x(0), y(0) {}
	Pt(ll xx, ll yy): x(xx), y(yy) {}
	Pt(const Pt & o): x(o.x), y(o.y) {}
	Pt operator+(const Pt & o) const {
		return Pt(x + o.x, y + o.y);
	}
	Pt operator-(const Pt & o) const {
		return Pt(x - o.x, y - o.y);
	}
	ll dot(const Pt & o) const {
		return x * o.x + y * o.y;
	}
	ll cross(const Pt & o) const {
		return x * o.y - y * o.x;
	}
	bool operator==(const Pt & o) const {
		return x == o.x && y == o.y;
	}
	bool operator!=(const Pt & o) const {
		return x != o.x || y != o.y;
	}
	bool operator<(const Pt & o) const {
		if (x != o.x) return x < o.x;
		return y < o.y;
	}
	Pt operator *(const ll &a) const {
		return Pt(x * a, y * a);
	}
	Pt operator *(const int &a) const {
		return Pt(x * a, y * a);
	}
	Pt operator /(const int &a) const {
		return Pt(x / a, y / a);
	}
	ll mag() const {
		return x * x + y * y;
	}
	int centeredQuadrant() const {
		if (x >= 0 && y >= 0) return 1;
		if (x <= 0 && y >= 0) return 2;
		if (x >= 0 && y <= 0) return 0;
		if (x <= 0 && y <= 0) return -1;
		throw "gg";
	}
};

ll area(const Pt & a, const Pt & b, const Pt & c) { // OF PARALLELOGRAM
	return (b - a).cross(c - a);
}

struct AngleComp {
	Pt center;
	AngleComp(Pt c): center(c) {}
	AngleComp(): center(Pt()) {}
	bool operator()(const Pt & a, const Pt & b) {
		assert(a != center);
		assert(b != center);
		int qa = (a - center).centeredQuadrant();
		int qb = (b - center).centeredQuadrant();
		if (qa != qb) {
			return qa < qb;
		}
		return area(center, a, b) > 0;
	}
	template<typename T> bool operator()(const pair<Pt, T> & a, const pair<Pt, T> & b) {
		if((*this)(a.first, b.first)) return true;
		if((*this)(b.first, a.first)) return false;
		return a.second < b.second;
	}
}
acomp;

bool wcmp(const Pt & orig, const Pt & a, const Pt & b) {
	ll w = (a - orig).cross(b - orig);
	if (w != 0) return w > 0;
	return (a - orig).mag() > (b - orig).mag();
}
Pt p0(-1337, -1337);
bool p0cmp(const Pt & a, const Pt & b) {
	return wcmp(p0, a, b);
}

void convexHull(vector<Pt> pts, vector<Pt> & out) {
	// DESTRUCTIVE
	out.clear();
	assert(pts.size() > 0);
	if (pts.size() == 1) {
		out.push_back(pts[0]); return;
	}
	
	p0 = *min_element(pts.begin(), pts.end());

	sort(allof(pts), p0cmp);

	out.push_back(p0);
	out.push_back(pts[0]);
	out.push_back(pts[1]);
	for (size_t s = 2; s < pts.size(); s++) {
		size_t sz = out.size();
		while (sz >= 3 && !wcmp(out[sz-2], out[sz-1], pts[s])) {
			out.pop_back();
			sz = out.size();
		}
		out.push_back(pts[s]);
	}
	out.pop_back(); // deduplicate last
	while (out.size() >= 2 && out[out.size() - 2] == out[out.size() - 1]) {
		out.pop_back(); // deduplicate in case of one unique point
	}
}

void test() {
	Pt center(5, 5);
	vector<Pt> pts;
	for (int i = 0; i <= 10; i++) {
		pts.push_back(Pt(0, i));
		pts.push_back(Pt(10, i));
		pts.push_back(Pt(i, 0));
		pts.push_back(Pt(i, 10));
	}
	for (int i = 4; i <= 6; i++) {
		pts.push_back(Pt(4, i));
		pts.push_back(Pt(6, i));
		pts.push_back(Pt(i, 4));
		pts.push_back(Pt(i, 6));
	}
	sort(allof(pts), AngleComp(center));
	for (const Pt & p : pts) {
		cout << p.x << "," << p.y << "\n";
	}
	vector<Pt> out;
	convexHull(pts, out);
	cout << "------\n";
	for (const Pt & p : out) {
		cout << p.x << "," << p.y << "\n";
	}
	cout << "------\n";
	pts.clear();
	pts.push_back(Pt(4, 4));
	pts.push_back(Pt(4, 4));
	pts.push_back(Pt(4, 4));
	pts.push_back(Pt(4, 4));
	pts.push_back(Pt(4, 4));
	convexHull(pts, out);
	for (const Pt & p : out) {
		cout << p.x << "," << p.y << "\n";
	}
	cout << "------\n";
	pts.clear();
	for (int i = -10; i <= 10; i++) {
		for (int j = -10; j <= 10; j++) {
			if (i * i + j * j <= 100) {
				pts.push_back(Pt(i, j));
			}
		}
		convexHull(pts, out);
	}
	for (const Pt & p : out) {
		cout << p.x << "," << p.y << "\n";
	}
	cout << "------\n";
	pts.clear();
	for (int i = -10; i <= 10; i++) {
		pts.push_back(Pt(i, i));
		convexHull(pts, out);
	}
	for (const Pt & p : out) {
		cout << p.x << "," << p.y << "\n";
	}
}

const int MAXN = 1e6;
int N;
vector<Pt> yes, no;
vector<Pt> hull;
int S;

inline Pt get(int i) {
	i %= N;
	if(i < 0) i += N;
	return hull[i];
}

// positive is in
ll check_line(Pt p, int i) {
	return sign(area(get(i), get(i + 1), p));
}

int go() {
	convexHull(yes, hull);
	S = int(hull.size());

	if(hull.size() == 1) {
		return 0;
	} else if(hull.size() == 2) {
		int ans = 0;
		for(Pt p : no) {
			if(area(hull[0], hull[1], p) == 0) {
				ans++;
			}
		}
		return ans;
	}
	acomp = AngleComp((hull[0] + hull[1] + hull[2]) / 3);

	vector<pair<Pt, bool>> sweep; // true is insert

	vector<pair<Pt, pair<int, int>>> vec;
	for(int i = 0; i < S; i++) {
		vec.emplace_back(hull[i], make_pair(1, i));
		vec.emplace_back(hull[i] * -1, make_pair(2, i));
	}
	for(Pt p : no) {
		vec.emplace_back(p, make_pair(0, 0));
	}
	sort(vec.begin(), vec.end(), acomp);

	int pp = 0, mp = 0;
	for(int i = 0; i < S; i++) {
		if(acomp(hull[i], pp)) pp = i;
		if(acomp(hull[i] * -1, mp)) mp = i;
	}

	for(auto it : vec) {
		if(it.second.first == 1) {
			pp = it.second.second;
		} else if(it.second.first == 2) {
			mp = it.second.second;
		} else {
			Pt p = it.first;

			if(check_line(p, pp - 1) && check_line(p, pp)) {
				// inside
				yes.push_back(p);
				continue;
			} else {
			}
		}
	}


	return res;

}

int main() {
	ios_base::sync_with_stdio(0);
	//test();
	cin >> N;
	for(int i = 0; i < N; i++) {
		ll a, b, c; cin >> a >> b >> c;
		a *= 6, b *= 6;
		if(c) {
			yes.emplace_back(a,b);
		} else {
			no.emplace_back(a,b);
		}
	}

	int ans = go();
	ans += int(yes.size());
	cout << ans << '\n';
}
