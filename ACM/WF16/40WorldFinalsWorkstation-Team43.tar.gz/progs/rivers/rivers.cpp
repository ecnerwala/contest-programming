#define NDEBUG
#include<bits/stdc++.h>
using namespace std;

#define fori(i,s,e) for(int i = s; i < ((int)e); i++)
#define allof(x) (x).begin(), (x).end()
typedef long long ll;

template<typename T> void minify(T & a, const T & b) {
	if (a > b) a = b;
}

int nSources, nConfs, root;

const int N = 1000008;
const ll OO = 2e18;
int parent[N];
ll dist[N];

string names[N];
ll answers[N];

ll rootdist[N];
ll minRootdist[N]; // of source descendant
ll srcDistOfParent[N];

vector<int> children[N];

int degree[N];

void distdfs(int v) {
	// call me with correct rootdist[v]
	assert(children[v].size() != 1 || v == root);
	degree[v] = children[v].size();
	if (children[v].size() == 0) {
		assert(v < root);
		minRootdist[v] = rootdist[v];
	} else {
		assert(v >= root);
		minRootdist[v] = OO;
		for (const int & w : children[v]) {
			rootdist[w] = rootdist[v] + dist[w];
			distdfs(w);
			minify(minRootdist[v], minRootdist[w]);
		}
	}
}

vector<int> sortedSources;

bool sscmp(int i, int j) {
	return rootdist[i] < rootdist[j];
}
void sortSources() {
	sortedSources.clear();
	for (int i = 0; i < nSources; i++) {
		sortedSources.push_back(i);
	}
	sort(allof(sortedSources), sscmp);
}

struct Leaf {
	int v;
	bool operator<(const Leaf & o) const {
		return srcDistOfParent[v] > srcDistOfParent[o.v];
	}
};

priority_queue<Leaf> leaves;

int main() {
	// assert(false);
	ios_base::sync_with_stdio(0);
	cin >> nSources >> nConfs;
	root = nSources;
	parent[root] = -1;
	rootdist[root] = 0;

	for(int i = 0; i < nSources; i++) {
		cin >> names[i] >> parent[i] >> dist[i];
		parent[i] += root;
		children[parent[i]].push_back(i);
	}
	for(int i = root + 1; i <= root + nConfs; i++) {
		cin >> parent[i] >> dist[i];
		parent[i] += root;
		children[parent[i]].push_back(i);
	}

	distdfs(root);

	sortSources();
	assert(sortedSources.size() == nSources);

	fori (i, 0, nSources + 1 + nConfs) {
		if (i == root) srcDistOfParent[i] = OO;
		else {
			srcDistOfParent[i] = minRootdist[i] - rootdist[i] + dist[i];
#ifndef NDEBUG
			cerr << "sDOP of " << i << " = " << srcDistOfParent[i] << "\n";
#endif
		}
	}

	for (int curSource : sortedSources) {
		leaves.push((Leaf) { .v = curSource });
#ifndef NDEBUG
		cerr << "  (Initial)Pushing " << curSource << "\n";
#endif
	}

	for (int curSource : sortedSources) {
		ll curThreshold = rootdist[curSource];
#ifndef NDEBUG
		cerr << "Current Source: " << curSource << " | Threshold: " << curThreshold << "\n";
#endif
		while (leaves.size() && srcDistOfParent[leaves.top().v] <= curThreshold) {
			int top = leaves.top().v;
#ifndef NDEBUG
			cerr << "  Popping " << top << "\n";
			cerr << "    because its sDOP is " << srcDistOfParent[leaves.top().v] << "\n";
#endif
			leaves.pop();
			int cp = parent[top];
			if (cp != -1) {
				degree[cp]--;
				assert(degree[cp] >= 0);
				if (degree[cp] == 0 && cp != root) {
					leaves.push((Leaf) { .v = cp });
#ifndef NDEBUG
					cerr << "  Pushing " << cp << "\n";
#endif
				}
			}
		}
		answers[curSource] = leaves.size() + 1;
#ifndef NDEBUG
		cerr << "  Answer (= leaves + 1) = " << answers[curSource] << "\n";
#endif
	}
	fori (i, 0, nSources) {
		cout << names[i] << " " << answers[i] << "\n";
	}
}
