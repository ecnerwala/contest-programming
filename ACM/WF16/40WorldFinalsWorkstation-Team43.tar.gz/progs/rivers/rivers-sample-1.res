PaSak 5
Nan 2
Yom 1
Wang 3
Ping 4
ThaChin 1
