#include <iostream>
#include <vector>
#include <string>

// Incorrect program. Only checks what happens when Marius always jumps into
// the left pipe.

std::vector<int> answers;

int main() {
  int N, K;
  std::cin >> N >> K;
  for (int k = 0; k < K; ++k) {
    std::cout << "? " << k << " ";
    for (int n = 0; n < N; ++n) {
      std::cout << "L";
    }
    std::cout << std::endl;
    int ans;
    std::cin >> ans;
    answers.push_back(ans);
  }
  std::cout << "!" << std::endl;
  int Q;
  std::cin >> Q;
  for (int q = 0; q < Q; ++q) {
    int k;
    std::string s;
    std::cin >> k >> s;
    bool known_query = true;
    for (int n = 0; n < N; ++n) {
      if (s[n] != 'L') known_query = false;
    }
    if (known_query) {
      std::cout << answers[k] << std::endl;
    } else {
      // Ooops, we have to guess.
      std::cout << 42 << std::endl;
    }
  }
  return 0;
}
