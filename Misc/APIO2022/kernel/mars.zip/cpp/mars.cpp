#include "mars.h"

long long process(std::vector<std::vector<long long> > a,int i,int j,int k,int n)
{
	return 0;
}