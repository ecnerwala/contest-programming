#include <cstdio>
#include <cstdlib>
#include <cstdarg>
#include <string>
#include <algorithm>
#include <iostream>
#include "mushrooms.h"
using namespace std;

static char fmt_buffer[100000];
#define FMT_TO_STR(fmt, result) va_list vargs; va_start(vargs, fmt); \
	vsnprintf(fmt_buffer, sizeof(fmt_buffer), fmt, vargs); \
	va_end(vargs); fmt_buffer[sizeof(fmt_buffer)-1] = 0; \
	std::string result(fmt_buffer);

static const int min_n = 2;
static const int max_n = 30;
static const int max_qc = 20000;
static const int max_qs = 100000;
static const int species_A = 0;
static const int species_B = 1;

static int n;
static std::vector<int> species;
static int qc, qs;

static inline void error_if(bool cond, std::string message) {
	if (cond) {
		printf("%s\n", message.c_str());
		exit(0);
	}
}

static inline void wrong_if(bool cond, std::string message) {
	error_if(cond, "Wrong Answer: "+message);
}

int use_machine(std::vector<int> x) {
	const int xs = x.size();
	wrong_if(xs < 2, "Too small array for query.");
	wrong_if(xs > n, "Too large array for query.");
	qc++;
	wrong_if(qc > max_qc, "Too many queries.");
	qs += xs;
	wrong_if(qs > max_qs, "Too many total array sizes as queries.");
	for (int i = 0; i < xs; i++)
		wrong_if(x[i] < 0 || n - 1 < x[i], "Invalid value in the query array.");
	std::vector<bool> used(n, false);
	for (int i = 0; i < xs; i++) {
		wrong_if(used[x[i]], "Duplicate value in the query array.");
		used[x[i]] = true;
	}
	int diffs = 0;
	for (int i = 1; i < xs; i++)
		diffs += int(species[x[i]] != species[x[i-1]]);
	return diffs;
}

#ifdef __GNUC__
__attribute__ ((format(printf, 2, 3)))
#endif
static inline void check_input(bool cond, const char* message_fmt, ...) {
	FMT_TO_STR(message_fmt, message);
	error_if(!cond, "Invalid input: "+message);
}

typedef unsigned int Int;

int main() {
	Int failures = 0;
	for (n=min_n; n<=max_n; n++) {
		cerr << "n: " << n << endl;
		Int P = 1 << n;
		for (Int p = 0; p < P; p+=2) {
			species.resize(n);
			for (int i=0; i<n; i++)
				species[i] = (p >> i) & 1;
			qc = 0;
			qs = 0;
			int answer = count_mushrooms(n);
			int correct = count(species.begin(), species.end(), species_A);
			if (correct != answer) {
				failures++;
				cout << n;
				for (int i=0; i<n; i++)
					cout << " " << species[i];
				cout << endl;
			}
		}
	}
	cerr << "failures: " << failures << endl;
	return 0;
}
