#!/bin/bash

set -eu
solution="$1"; shift
problem=mushrooms
grader_name=stub

g++ -std=gnu++17 -O2 -Wall -pipe -static -I"../grader/cpp" -o "${problem}.exe" "${grader_name}.cpp" "${solution}"
