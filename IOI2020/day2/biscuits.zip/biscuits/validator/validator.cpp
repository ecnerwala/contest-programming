#include "testlib.h"
using namespace std;

const int MAXK = 60;
const int MAXQ = 1000;
const long long MAXX = 1000000000000000000LL;
const long long MAXA = 1000000000000000000LL;
const long long MAXSUM = 1000000000000000000LL;

int main() {
	registerValidation();
	string secret = inf.readLine();
	ensuref(secret == (string)"1b32a07d5f5fc55f21038b12a3655e", "Secret not found!");
	int q = inf.readInt(1, MAXQ, "q");
	inf.readEoln();
	for (int t = 0; t < q; t++) {
		int k = inf.readInt(1, MAXK, "k");
		inf.readSpace();
		inf.readLong(1, MAXX, "x");
		inf.readEoln();
		long long sum = 0;
		for (int i = 0; i < k; i++) {
			if(i)
				inf.readSpace();
			long long a = inf.readLong(0, MAXA, "a_i");
			ensuref(a <= MAXSUM / (1ll << i) && (sum += a * (1ll << i)) <= MAXSUM, "Sum of tastiness of biscuits exceeds %lld", MAXSUM);
		}
		inf.readEoln();
	}
	inf.readEof();
	return 0;
}
