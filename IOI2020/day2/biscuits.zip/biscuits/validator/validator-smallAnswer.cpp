#include "testlib.h"
#include <map>
#include <vector>
using namespace std;

//TODO: Update subtask name and finalize constraints (currently MAXQ = 1000, MAXSOLS = 2e5)

const int MAXK = 60;
const int MAXQ = 1000;
const long long MAXX = 1000000000000000000LL;
const long long MAXA = 1000000000000000000LL;
const long long MAXSUM = 1000000000000000000LL;
const long long MAXSOLS = 200000;

//***************TAKEN FROM YH's SOLUTION*********************

map<long long, long long> m;
long long f(vector<long long> &s, long long x, long long n) {
    if(n<=0) return 0;
    if(n==1) return 1;
    if(m.find(n)!=m.end()) {
        return m[n];
    }
    long long a = 63-__builtin_clzll(n-1);
    return m[n] = f(s,x,1LL<<a) + f(s,x,min(n,1+s[a]/x)-(1LL<<a));
}
long long count_tastiness(long long x, std::vector<long long> a) {
    m.clear();
    for(int i=1; i<(int)a.size(); i++) {
        a[i] = a[i-1] + (a[i]<<i);
    }
    while(a.size()<=60) a.push_back(a.back());
	return f(a, x, 1+a.back());
}

//***********************************************************

int main() {
	registerValidation();
	string secret = inf.readLine();
	ensuref(secret == (string)"1b32a07d5f5fc55f21038b12a3655e", "Secret not found!");
	int q = inf.readInt(1, MAXQ, "q");
	inf.readEoln();
	for (int t = 0; t < q; t++) {
		int k = inf.readInt(1, MAXK, "k");
		inf.readSpace();
		int X = inf.readLong(1, MAXX, "x");
		inf.readEoln();
		long long sum = 0;
		
		vector<long long> A;
		for (int i = 0; i < k; i++) {
			if(i)
				inf.readSpace();
			long long a = inf.readLong(0, MAXA, "a_i");
			ensuref(a <= MAXSUM / (1ll << i) && (sum += a * (1ll << i)) <= MAXSUM, "Sum of tastiness of biscuits exceeds %lld", MAXSUM);
			A.push_back(a);
		}
		ensuref(count_tastiness(X, A) <= MAXSOLS, "Number of answers exceeds %lld", MAXSOLS);
		inf.readEoln();
	}
	inf.readEof();
	return 0;
}
