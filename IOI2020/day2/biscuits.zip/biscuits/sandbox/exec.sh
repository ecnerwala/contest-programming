#!/bin/bash

problem_name=biscuits
sandbox=$(dirname "$0")

"${sandbox}/${problem_name}.exe" "$@"
