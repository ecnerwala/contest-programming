#include "jelly.h"
#include <cstdio>
#include <cassert>
#include <vector>
// BEGIN SECRET
#include <string>
// END SECRET

static int n, x, y;
static std::vector<int> a, b;

int main() {
    // BEGIN SECRET
    const std::string input_secret = "5291aba8-79fa-474c-9bdc-9b40d84252ce";
    const std::string output_secret = "81d4c275-78fc-4b65-81cb-4c3f7cfaa7da";
    char secret[1000];
    assert(1 == scanf("%s", secret));
    if (std::string(secret) != input_secret) {
        printf("%s\n", output_secret.c_str());
        printf("SV\n");
        fclose(stdout);
        return 0;
    }
    // END SECRET
    assert(scanf("%d %d %d", &n, &x, &y) == 3);
    a.resize(n);
    b.resize(n);
    for (int i = 0; i < n; i++) {
        assert(scanf("%d %d", &a[i], &b[i]) == 2);
    }

    fclose(stdin);

    int answer = find_maximum_unique(x, y, a, b);

    // BEGIN SECRET
    printf("%s\n", output_secret.c_str());
    printf("OK\n");
    // END SECRET
    printf("%d\n", answer);
}
