#!/bin/bash

problem_name=jelly
sandbox=$(dirname "$0")

"${sandbox}/${problem_name}.exe" "$@"
