import java.util.Arrays;

class IntPair implements Comparable<IntPair> {
	final int first, second;
	public IntPair(int _first, int _second) {
		first = _first;
		second = _second;
	}
	@Override
	public int compareTo(IntPair other) {
		return first - other.first;
	}
}

class jelly {

	int find_maximum_unique(int x, int y, int[] a, int[] b) {
		int n = a.length;
		int[][] fdp = new int[n+1][x+1];
		int[][] bdp = new int[n+1][y+1];
		IntPair[] c = new IntPair[n];
		for (int i = 0; i < n; i++) {
			c[i] = new IntPair(a[i], b[i]);
		}
		Arrays.sort(c);
		for(int i = 1; i <= n; i++) {
			for(int j = 0; j <= x; j++) {
				fdp[i][j] = fdp[i-1][j] + c[i-1].second;
				if (j >= c[i - 1].first) {
					fdp[i][j] = Math.min(fdp[i][j], fdp[i-1][j- c[i-1].first]);
				}
			}
		}
		
		for(int i = n-1; i>=0; i--){
			for(int j = 0; j <= y; j++) {
				bdp[i][j]=bdp[i + 1][j];
				if (j >= c[i].second){
					bdp[i][j]= Math.max(bdp[i][j],bdp[i + 1][j - c[i].second] + 1);
				}
			}
		}		
		int ans = 0;
		for(int i=0; i<=n; i++) {
			int yleft = y - fdp[i][x];
			if (yleft>=0) {
				ans = Math.max(ans, i + bdp[i][yleft]);
			}
		}
		return ans;
	}
}
