#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

const int MAXN = 2000;
const int MAXX = 10000;
const int MAXY = 0;

int main() {
    registerValidation();

    inf.readLine(); // Input secret

    inf.readInt(1, MAXN, "n");
    inf.readSpace();
    inf.readInt(0, MAXX, "x");
    inf.readSpace();
    inf.readInt(0, MAXY, "y");
    inf.readEoln();
   
	skip_ok();
}



