#include "testlib.h"
using namespace std;

const string input_secret = "5291aba8-79fa-474c-9bdc-9b40d84252ce";

const int MAXN = 2000;
const int MAXX = 10000;
const int MAXY = 10000;
const int MAXAB = 10000;

int main() {
    registerValidation();

    string secret = inf.readLine();
    ensuref(secret == input_secret, "Secret not found!");

    int n = inf.readInt(1, MAXN, "n");
    inf.readSpace();
    int x = inf.readInt(0, MAXX, "x");
    inf.readSpace();
    int y = inf.readInt(0, MAXY, "y");
    inf.readEoln();
    
    vector<int> a, b;
    a.resize(n);
    b.resize(n);
    for (int i = 0; i < n; i++) {
		a[i] = inf.readInt(0, MAXAB, "a_i");
		inf.readSpace();
		b[i] = inf.readInt(0, MAXAB, "b_i");
		inf.readEoln();
	}
    inf.readEof();
    return 0;
}
