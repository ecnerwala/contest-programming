#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

const int MAXN = 2000;
const int MAXX = 10000;
const int MAXY = 10000;
const int MAXAB = 10000;

int main() {
    registerValidation();

    inf.readLine(); // Input secret

    int n = inf.readInt(1, MAXN, "n");
    inf.readSpace();
    int x = inf.readInt(0, MAXX, "x");
    inf.readSpace();
    int y = inf.readInt(0, MAXY, "y");
    inf.readEoln();
    
    vector<int> a, b;
    a.resize(n);
    b.resize(n);
    for (int i = 0; i < n; i++) {
		a[i] = inf.readInt(0, MAXAB, "a_i");
		inf.readSpace();
		b[i] = inf.readInt(0, MAXAB, "b_i");
		inf.readEoln();
	}
	for (int i = 0; i < n; i++) ensuref(b[i] == b[0], "b must be same");
    inf.readEof();
    return 0;
}

