#include "testlib.h"
#include <bits/stdc++.h>
using namespace std;

const int MAXN = 12;
const int MAXX = 500;
const int MAXY = 500;
const int MAXAB = 10000;

int main() {
    registerValidation();

    inf.readLine(); // Input secret

    inf.readInt(1, MAXN, "n");
    inf.readSpace();
    inf.readInt(0, MAXX, "x");
    inf.readSpace();
    inf.readInt(0, MAXY, "y");
    inf.readEoln();
   
	skip_ok();
}

