#include "testlib.h"
#include <vector>

std::string output_secret = "81d4c275-78fc-4b65-81cb-4c3f7cfaa7da";

int main(int argc, char * argv[]) {
    registerChecker("jelly", argc, argv);
    
    readBothSecrets(output_secret);
    readBothGraderResults();

    compareRemainingLines();
}
