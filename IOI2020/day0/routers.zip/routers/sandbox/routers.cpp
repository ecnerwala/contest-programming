#include "routers.h"
#include <bits/stdc++.h>
using namespace std;

vector<int> ans, dist;

void bs(int s, int e, int a, int b) {
    if (a > b) return;
    if (e - s == b - a) {
        for (int i = s; i <= e; i++) {
            dist.push_back(i);
        }
        return;
    }
    if (s + 1 == e) {
        if (use_detector(e) == a) {
            dist.push_back(e);
        } else {
            dist.push_back(s);
        }
        return;
    }
    int m = (s + e) / 2;
    int hi = use_detector(m);
    bs(s, m - 1, a, hi - 1);
    bs(m, e, hi, b);
}

vector<int> find_routers(int l, int n, int q) {
    bs(0, l, 0, n - 2);
    ans.resize(n);
    ans[0] = 0;
    for (int i = 1; i < n; i++)
    {
        ans[i] = 2 * dist[i - 1] - ans[i - 1];
    }
    return ans;
}