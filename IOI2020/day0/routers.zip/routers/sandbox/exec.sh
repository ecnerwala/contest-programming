#!/bin/bash

problem_name=routers
sandbox=$(dirname "$0")

"${sandbox}/${problem_name}.exe" "$@"
