#include "routers.h"
#include <bits/stdc++.h>
using namespace std;


int bs(int s,int e,int id){
    if(s==e)return s;
    if(s+1==e){
        if(use_detector(e)==id)return e;
        return s;
    }
    int m=(s+e)/2;
    int hi = use_detector(m);
    if(hi>id) return bs(s,m-1,id);
    return bs(m,e,id);
}

vector<int> v;
vector<int> find_routers(int L, int N, int Q) {
	vector<int> ans;
	for(int i=0;i<N-1;i++){
        v.push_back(bs(0,L,i));
	}
	//for(int i:v)printf("%d ",i);printf("\n");
	ans.push_back(0);
	for(int i=1;i<N;i++){
        ans.push_back(2*v[i-1]-ans[i-1]);
	}
	return ans;
}
