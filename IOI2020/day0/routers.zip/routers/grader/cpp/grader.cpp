#include "routers.h"
#include <vector>
#include <cassert>
#include <cstdio>
#include <algorithm>
// BEGIN SECRET
#include <string>
// END SECRET

static int l, n, q;
static std::vector<int> p;
static std::vector<int> answer;
static int queries = 0;

int use_detector(int x)
{
	queries++;
    assert(x >= 0 && x <= l);
    std::vector<int>::iterator left, right;
    right = std::upper_bound(p.begin(), p.end(), x);
    left = std::prev(right);

    if (right == p.end()) {
        return n - 1;
    } else if ((x - *left) <= (*right - x)){
        return std::distance(p.begin(), left);
    } else {
        return std::distance(p.begin(), right);
    }
}

int main()
{
    // BEGIN SECRET
    const std::string input_secret = "d347d899-a30c-4780-8a57-1113ba248f76";
    const std::string output_secret = "8b6df172-f5d3-4789-b2d8-76a7791dd878";
    char secret[1000];
    assert(1 == scanf("%s", secret));
    if (std::string(secret) != input_secret) {
        printf("%s\n", output_secret.c_str());
        printf("SV\n");
        fclose(stdout);
        return 0;
    }
    // END SECRET
    assert(scanf("%d %d %d", &l, &n, &q) == 3);
    p.resize(n);
    for (int i = 0; i < n; i++) {
        assert(scanf("%d", &p[i]) == 1);
        if (i) {
            assert(p[i-1] < p[i]);
        }
    }

    fclose(stdin);

    answer = find_routers(l, n, q);

    assert((int) answer.size() == n);
    for (int i = 0; i < n; i++)
    {
        assert(answer[i] >= 0 && answer[i] <= l && answer[i] % 2 == 0);
    }

    // BEGIN SECRET
    printf("%s\n", output_secret.c_str());
    printf("OK\n");
    // END SECRET
    for (int i = 0; i < n; i++)
    {
        if (i) printf(" ");
        printf("%d", answer[i]);
    }
    printf("\n");

    printf("%d\n", queries);
}
