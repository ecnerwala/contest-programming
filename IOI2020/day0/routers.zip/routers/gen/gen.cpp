#include "testlib.h"
using namespace std;

int main(int argc, char* argv[]) {
    registerGen(argc, argv, 0);
    
    int st = atoi(argv[1]);
    int tc = atoi(argv[2]);

    int l, n, q;
    l = 1e5;

    if (st == 1) {
        n = 2;
        q = 100001;
    } else if (st == 2) {
        n = 100;
        q = 100001;
    } else if (st == 3) {
        n = 2;
        q = 20;
    } else {
        n = 1000;
        q = 20000;
    }

    printf("%d %d %d\n", l, n, q);

    vector<int> p;
    p.resize(n);

    p[0] = 0;

    if (tc == 1) {
        // Routers as close to 0 as possible
        for (int i = 1; i < n; i++) {
            p[i] = i * 2;
        }
    } else if (tc == 2) {
        // Routers as far as possible
        for (int i = 1; i < n; i++) {
            p[i] = l - 2 * (n - 1 - i);
        }
    } else {
        // Randomly generate p
        set<int> s;
        s.insert(0);
        for (int i = 1; i < n; i++) {
            int newv = rnd.next(l/2) * 2 + 2;
            while (s.find(newv) != s.end()) {
                newv = rnd.next(l/2) * 2 + 2;
            }
            s.insert(newv);
            p[i] = newv;
        }
        sort(p.begin(), p.end());
    }

    for (int i = 0; i < n; i++) {
        if (i) {
            printf(" ");
        }
        printf("%d", p[i]);
    }
    printf("\n");
}

