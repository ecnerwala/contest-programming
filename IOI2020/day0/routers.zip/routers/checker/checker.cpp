#include "testlib.h"

const std::string output_secret = "8b6df172-f5d3-4789-b2d8-76a7791dd878";

int main(int argc, char * argv[]) {
    registerChecker("gift", argc, argv);
    
    readBothSecrets(output_secret);
    readBothGraderResults();

    std::vector<int> answer, actual;

    inf.readLine(); // Input secret

    int l, n, q;
    l = inf.readInt();
    n = inf.readInt();
    q = inf.readInt();

    answer = ouf.readInts(n, 0, l, "p_i");
    actual = inf.readInts(n, 0, l, "p_i");

    int queries_used = ouf.readInt();

    if (answer != actual) {
        quit(_wa, "Incorrect location of routers");
    }

    if (queries_used > q) {
        quit(_wa, "Too many queries used");
    }

    bool is_st4 = (n == 1000) && (q == 20000);

    if (is_st4) {
        if (queries_used <= 7500) {
            quit(_ok);
        } else {
            quitp((0.0 + 20000 - queries_used) / 125000.0, "Partial score");
        }
    } else {
        quit(_ok);
    }
}