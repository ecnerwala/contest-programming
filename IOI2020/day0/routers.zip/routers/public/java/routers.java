class routers {
	int[] find_routers(int l, int n, int q) {
		int idx = grader.use_detector(0);
		int[] ans = new int[n];
		for(int i = 0; i < n; i++) {
			ans[i] = 0;
		}
		return ans;
	}
}
