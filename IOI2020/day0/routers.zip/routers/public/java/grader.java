import java.io.PrintWriter;
import java.io.IOException;
import java.io.InputStream;
import java.util.InputMismatchException;

public class grader {
	private static int l, n, q;
	private static int[] p;
	private static int[] answer;
	private static int queries = 0;
	
	public static int use_detector(int x) {
		queries++;
		if (x < 0 || x > l) {
			throw new RuntimeException();
		}
		
		// binary search
		int lo = 0;
		int hi = p.length;
		while(hi - lo > 1) {
			int mid = (lo + hi) / 2;
			if (p[mid] > x) {
				hi = mid;
			} else {
				lo = mid;
			}
		}
		
		if(hi == n) {
			return n - 1;
		} else if((x - p[lo] <= p[hi] - x)) {
			return lo;
		} else {
			return hi;
		}
	}
	
	public static void main(String[] args) {
		InputReader inputReader = new InputReader(System.in);
		l = inputReader.readInt();
		n = inputReader.readInt();
		q = inputReader.readInt();
		p = new int[n];
		for (int i = 0; i < n; i++) {
			p[i] = inputReader.readInt();
		}
		
		inputReader.close();
		
		routers solver = new routers();
		answer = solver.find_routers(l, n, q);
		
		PrintWriter out = new PrintWriter(System.out);
		for (int i = 0; i < n; i++) {
			if (i > 0) {
				out.print(" ");
			}
			out.print(answer[i]);
		}
		out.println();
		out.println(queries);
		out.flush();
		out.close();
	}
}

class InputReader implements java.io.Closeable {
	private java.io.InputStream stream;
	private byte[] buf = new byte[1024];
	private int curChar;
	private int numChars;

	public InputReader(java.io.InputStream stream) {
		this.stream = stream;
	}
	
	@Override
	public void close() {
		try {
			this.stream.close();
		} catch (java.io.IOException e) {
		}
	}

	public int read() {
		if (numChars == -1) {
			throw new java.util.InputMismatchException();
		}
		if (curChar >= numChars) {
			curChar = 0;
			try {
				numChars = stream.read(buf);
			} catch (java.io.IOException e) {
				throw new java.util.InputMismatchException();
			}
			if (numChars <= 0) {
				return -1;
			}
		}
		return buf[curChar++];
	}

	public int readInt() {
		int c = eatWhite();
		int sgn = 1;
		if (c == '-') {
			sgn = -1;
			c = read();
		}
		int res = 0;
		do {
			if (c < '0' || c > '9') {
				throw new java.util.InputMismatchException();
			}
			res *= 10;
			res += c - '0';
			c = read();
		} while (!isSpaceChar(c));
		return res * sgn;
	}

	public long readLong() {
		int c = eatWhite();
		long sgn = 1;
		if (c == '-') {
			sgn = -1;
			c = read();
		}
		long res = 0;
		do {
			if (c < '0' || c > '9') {
				throw new java.util.InputMismatchException();
			}
			res *= 10;
			res += c - '0';
			c = read();
		} while (!isSpaceChar(c));
		return res * sgn;
	}

	public String readString() {
		int c = eatWhite();
		StringBuilder res = new StringBuilder();
		do {
			if (Character.isValidCodePoint(c))
				res.appendCodePoint(c);
			c = read();
		} while (!isSpaceChar(c));
		return res.toString();
	}

	public String readLine() {
		StringBuilder res = new StringBuilder();
		while (true) {
			int c = read();
			if (c == '\n' || c == '\r' || c == -1)
				break;
			if (Character.isValidCodePoint(c))
				res.appendCodePoint(c);
		}
		return res.toString();
	}

	private int eatWhite() {
		int c = read();
		while (isSpaceChar(c)) {
			c = read();
		}
		return c;
	}

	public static boolean isSpaceChar(int c) {
		return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
	}
}
