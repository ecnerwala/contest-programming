#include "testlib.h"
using namespace std;

const int MAXL = 1e5;
const int N = 2;
const int Q = 1e5 + 1;

int main() {
    registerValidation();

    inf.readLine(); // Read input secret

    inf.readInt(MAXL, MAXL, "l");
    inf.readSpace();
    inf.readInt(N, N, "n");
    inf.readSpace();
    inf.readInt(Q, Q, "q");

    skip_ok();

    return 0;
}