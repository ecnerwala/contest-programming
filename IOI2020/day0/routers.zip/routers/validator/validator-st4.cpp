#include "testlib.h"
using namespace std;

const int MAXL = 1e5;
const int N = 1000;
const int Q = 20000;

int main() {
    registerValidation();

    inf.readLine(); // Read input secret

    inf.readInt(MAXL, MAXL, "l");
    inf.readSpace();
    inf.readInt(N, N, "n");
    inf.readSpace();
    inf.readInt(Q, Q, "q");

    skip_ok();

    return 0;
}