#include "testlib.h"
using namespace std;

const std::string input_secret = "d347d899-a30c-4780-8a57-1113ba248f76";

const int L = 1e5;
const int MAXN = 1000;
const int MAXQ = 1e5 + 1;

int main() {
    registerValidation();

    string secret = inf.readLine();
    ensuref(secret == input_secret, "Secret not found!");

    int l, n;
    l = inf.readInt(L, L, "l");
    inf.readSpace();
    n = inf.readInt(1, MAXN, "n");
    inf.readSpace();
    inf.readInt(1, MAXQ, "q");
    inf.readEoln();

    vector<int> p = inf.readInts(n, 0, l, "p_i");
    for (int i = 0 ; i < n; i++) {
        ensuref(p[i] % 2 == 0, "p_i must be even!");
        if (i) {
            ensuref(p[i] > p[i-1], "p_i must be strictly increasing!");
        }
    }
    inf.readSpace();

    inf.readEoln();
    inf.readEof();

    return 0;
}
