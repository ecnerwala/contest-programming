#include "testlib.h"
using namespace std;

const int MAXN = 5e5;
const int MAXR = 5e5;

int main() {
    registerValidation();

    // Read input secret
    inf.readLine();

    int n = inf.readInt(1, MAXN, "n");
    inf.readSpace();
    int r = inf.readInt(1, MAXR, "r");
    inf.readEoln();

    vector<int> a, b, x;
    a.resize(r);
    b.resize(r);
    x.resize(r);
    for (int i = 0; i < r; i++) {
        inf.readInt(0, n-1, "a_i");
        inf.readSpace();
        inf.readInt(0, n-1, "b_i");
        inf.readSpace();

        // x[i] == 1
        x[i] = inf.readInt(2, 2, "x_i");
        inf.readEoln();
        ensuref(a[i] <= b[i], "a_i must be smaller than b_i!");
    }

    inf.readEof();
    return 0;
}