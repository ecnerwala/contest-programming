#include "testlib.h"
using namespace std;

const int MAXN = 5e5;
const int MAXR = 5e5;

const std::string input_secret = "c757a460-0663-48a2-bf13-8757d15480a4";

int main() {
    registerValidation();

    string secret = inf.readLine();
    ensuref(secret == input_secret, "Secret not found!");

    int n = inf.readInt(1, MAXN, "n");
    inf.readSpace();
    int r = inf.readInt(1, MAXR, "r");
    inf.readEoln();

    vector<int> a, b, x;
    a.resize(r);
    b.resize(r);
    x.resize(r);
    for (int i = 0; i < r; i++) {
        a[i] = inf.readInt(0, n-1, "a_i");
        inf.readSpace();
        b[i] = inf.readInt(0, n-1, "b_i");
        inf.readSpace();
        x[i] = inf.readInt(1, 2, "x_i");
        inf.readEoln();
        ensuref(a[i] <= b[i], "a_i must be smaller than b_i!");
    }

    inf.readEof();
    return 0;
}