#include "testlib.h"
using namespace std;

const int MAXN = 18;
const int MAXR = 18;

int main() {
    registerValidation();

    // Read input secret
    inf.readLine();

    int n = inf.readInt(1, MAXN, "n");
    inf.readSpace();
    int r = inf.readInt(1, MAXR, "r");
    inf.readEoln();

    skip_ok();
    return 0;
}