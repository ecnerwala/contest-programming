#include "gift.h"

int construct(int n, int r, std::vector<int> a, std::vector<int> b,  std::vector<int> x)
{
    std::string s;
    for (int i = 0; i < n; i++) {
        s += "R";
    }
    craft(s);
    return 1;
}