#include "gift.h"

int construct(int n, int r, std::vector<int> a, std::vector<int> b,  std::vector<int> x)
{
	for (int i = 0; i < r; i++) if (a[i] == b[i]) return 0;
    std::string s;
    for (int i = 0; i < n; i++) {
        s += (i%2)?"R":"B";
    }
    craft(s);
    return 1;
}
