#include "gift.h"
#include <vector>
#include <cassert>
#include <cstdio>
#include <string>

static int n, r;
static std::vector<int> a, b, x;
static std::string s;
static int possible = 0;
static int called = 0;

void craft(std::string &_s)
{
    assert(!called);
    s = _s;
    assert((int) s.size() == n);
    for (int i = 0; i < n; i++) {
        assert(s[i] == 'R' || s[i] == 'B');
    }
    called = 1;
}

int main()
{
    // BEGIN SECRET
    const std::string input_secret = "c757a460-0663-48a2-bf13-8757d15480a4";
    const std::string output_secret = "7786a2e7-2323-4412-a6d8-c4b72ec93f70";
    char secret[1000];
    assert(1 == scanf("%s", secret));
    if (std::string(secret) != input_secret) {
        printf("%s\n", output_secret.c_str());
        printf("SV\n");
        fclose(stdout);
        return 0;
    }
    // END SECRET
    assert(scanf("%d %d", &n, &r) == 2);
    a.resize(r);
    b.resize(r);
    x.resize(r);
    for (int i = 0; i < r; i++) {
        assert(scanf("%d %d %d", &a[i], &b[i], &x[i]) == 3);
    }

    fclose(stdin);

    possible = construct(n, r, a, b, x);

    assert(possible == 0 || possible == 1);

    // BEGIN SECRET
    printf("%s\n", output_secret.c_str());
    printf("OK\n");
    // END SECRET
    printf("%d\n", possible);

    if (possible == 1) {
        printf("%s\n", s.c_str());
    } else {
        assert(!called);
    }

}
