#include "testlib.h"
#include "optparse.h"
using namespace std;

const int MAXN = 5e5;
const int MAXR = 5e5;

int logRandom(int from, int to) {
    // Returns an integer between (from, to)
    // With an exponential-logarithmic distribution
    if (from == to) return from;
    return from + int(exp(rnd.next(log(double(to - from)))));
}

int uniformRandom(int from, int to) {
    return rnd.next(from, to);
}

int main(int argc, char **argv) {
    registerGen(argc, argv, 0);

    optparse::OptionParser parser = optparse::OptionParser();
    parser.description("Randomized testcase generator for gift");

    parser.add_option("-n", "--max-n")
        .dest("n")
        .type("int")
        .help("Maximum number of beads in necklace")
        .set_default(to_string(MAXN));
    
    parser.add_option("-r", "--max-r")
        .dest("r")
        .type("int")
        .help("Maximum number of requirements")
        .set_default(to_string(MAXR));

    parser.add_option("-x", "--allowed-x")
        .dest("x")
        .type("string")
        .help("Allowed types of x [\"1\"/\"2\"/\"12\"]")
        .set_default("12");
        
    parser.add_option("-s", "--number-of-splits")
        .dest("s")
        .type("int")
        .set_default("1");
    
    parser.add_option("-i", "--impossible")
        .dest("i")
        .type("int")
        .set_default("0");

    const optparse::Values options = parser.parse_args(argc, argv);

    int n = options.get("n");
    int r = options.get("r");
    std::string xs = options["x"];
    
    int ranges = options.get("s");
    set<int> split;
    while (split.size() < ranges) split.insert(uniformRandom(0, n-1));
    int cur = 0;
    while (split.size() == 1) {
		split.insert(cur);
		cur++;
	}
    vector<int> splits;
    for (set<int>::iterator it = split.begin(); it != split.end(); it++) splits.push_back(*it);
    vector< pair<int, int> > allowed_ranges;
    for (int i = 0; i < (int)splits.size() - 1; i++) {
		int b = splits[i], e = splits[i+1];
		int r1 = uniformRandom(b, e);
		int r2 = uniformRandom(b, e);
		allowed_ranges.push_back(make_pair(min(r1, r2), max(r1, r2)));
	}
	sort(allowed_ranges.begin(), allowed_ranges.end());
	int impossible = options.get("i");

    printf("%d %d\n", n, r);
    for (int i = 0; i < r; i++) {
        int a, b, x;
        x = rnd.next((int) xs.size());
        if (xs[x] == '2') {
			a = rnd.next(n);
			b = rnd.next(n);
			if (impossible == 0) {
				while (1) {
					a = rnd.next(n);
					b = rnd.next(n);
					int idx = lower_bound(allowed_ranges.begin(), allowed_ranges.end(), make_pair(min(a, b), 1000000000)) - allowed_ranges.begin() - 1;
					if (a == b) continue;
					if (idx < 0) break;
					if (allowed_ranges[idx].second < max(a, b)) break;
				}
			}
		} else {
			int range = uniformRandom(0, allowed_ranges.size() - 1);
			//fprintf(stderr, "range: %d (%d, %d)\n", range, allowed_ranges[range].first, allowed_ranges[range].second);
			a = uniformRandom(allowed_ranges[range].first, allowed_ranges[range].second);
			b = uniformRandom(allowed_ranges[range].first, allowed_ranges[range].second);
		}
        
        if (a > b) std::swap(a, b);
        printf("%d %d %c\n", a, b, xs[x]);
    }
}
