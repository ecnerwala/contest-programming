#include "testlib.h"

const std::string output_secret = "7786a2e7-2323-4412-a6d8-c4b72ec93f70";

int main(int argc, char * argv[]) {
    registerChecker("gift", argc, argv);
    
    readBothSecrets(output_secret);
    readBothGraderResults();

    inf.readLine(); // Input secret

    int answer = ouf.readInt();
    int actual = ans.readInt();

    if (answer != actual) {
        quit(_wa, "Possible does not match answer file");
    }

    if (answer) {
        int n = inf.readInt();
        int r = inf.readInt();

        std::vector<int> reds;
        std::vector<int> blues;
        reds.resize(n+1);
        blues.resize(n+1);
        reds[0] = 0;
        blues[0] = 0;

        ouf.readEoln();
        std::string necklace = ouf.readString();

        for (int i = 0; i < n; i++) {
            if (necklace[i] == 'R') {
                reds[i+1]++;
            } else if (necklace[i] == 'B') {
                blues[i+1]++;
            } else {
                quitf(_pe, "Unknown character at position %d", i);
            }
            reds[i+1] += reds[i];
            blues[i+1] += blues[i];
        }

        auto check = [&](int start, int end) {
            int has_red = reds[end+1] - reds[start] > 0;
            int has_blue = blues[end+1] - blues[start] > 0;
            return has_red + has_blue;
        };

        for (int i = 0; i < r; i++) {
            int a = inf.readInt();
            int b = inf.readInt();
            int x = inf.readInt();
            if (check(a, b) != x) {
                quitf(_wa, "Requirement %d not satisfied", i);
            }
        }
    }

    quit(_ok);
}