#!/bin/bash

problem_name=gift
sandbox=$(dirname "$0")

"${sandbox}/${problem_name}.exe" "$@"
