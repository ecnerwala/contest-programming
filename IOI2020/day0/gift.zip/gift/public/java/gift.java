public class gift {

	int construct(int n, int r, int[] a, int[] b, int[] x) {
		char[] array = new char[n];
		for (int i = 0; i < n; i++)
			array[i] = 'R';
		String s = new String(array);
		grader.craft(s);
		return 1;
	}
}
