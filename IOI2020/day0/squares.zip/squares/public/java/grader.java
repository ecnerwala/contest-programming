import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.util.InputMismatchException;
import java.util.Arrays;
import java.util.ArrayList;

public class grader {
  private static int max_k = 0;
  private static int r, n, k, q, x;
  private static int[] labels, c;
  private static ArrayList<Integer> answers;

	public static void main(String[] args) {
		InputReader inputReader = new InputReader(System.in);
		r = inputReader.readInt();
		squares solver = new squares();
		answers = new ArrayList<>();
	  for (int tc = 0; tc < r; tc++) {
	    n = inputReader.readInt();
	    q = inputReader.readInt();
		  labels = solver.paint(n);
  		if (labels == null || labels.length != n + 1) {
  			System.out.println("Number of labels not equal to " + (n + 1));
				System.exit(0);
  		}
  		for (int i = 0; i < n; i++) {
  			if (labels[i] != 0 && labels[i] != 1) {
  				System.out.println("Label not 0 or 1");
  			  System.exit(0);
  			}
  		}
  		k = labels[n];
			if (k < 0 || k > 1000) {
				System.out.println("Label not in range 0 to 1000");
				System.exit(0);
			}
			if (k > max_k) {
				max_k =k;
			}
  		for (int i = 0; i < q; i++) {
    		x = inputReader.readInt();
    		c = new int[k];
  			for (int j = x; j < x + k; j++) {
					if (j >= n) {
						c[j - x] = -1;
					} else {
						c[j - x] = labels[j];
					}
  			}
  			answers.add(solver.find_location(n, c));
  		}
	  }
  	System.out.println(max_k);
  	for (Integer ans : answers) {
  		System.out.println(ans);
  	}
  	System.exit(0);
	}
}

class InputReader {
	private InputStream stream;
	private byte[] buf = new byte[1024];
	private int curChar;
	private int numChars;

	public InputReader(InputStream stream) {
		this.stream = stream;
	}

	public int read() {
		if (numChars == -1) {
			throw new InputMismatchException();
		}
		if (curChar >= numChars) {
			curChar = 0;
			try {
				numChars = stream.read(buf);
			} catch (IOException e) {
				throw new InputMismatchException();
			}
			if (numChars <= 0) {
				return -1;
			}
		}
		return buf[curChar++];
	}

	public int readInt() {
		int c = eatWhite();
		int sgn = 1;
		if (c == '-') {
			sgn = -1;
			c = read();
		}
		int res = 0;
		do {
			if (c < '0' || c > '9') {
				throw new InputMismatchException();
			}
			res *= 10;
			res += c - '0';
			c = read();
		} while (!isSpaceChar(c));
		return res * sgn;
	}

	public String readString() {
		int c = eatWhite();
		StringBuilder res = new StringBuilder();
		do {
			if (Character.isValidCodePoint(c))
				res.appendCodePoint(c);
			c = read();
		} while (!isSpaceChar(c));
		return res.toString();
	}

	private int eatWhite() {
		int c = read();
		while (isSpaceChar(c)) {
			c = read();
		}
		return c;
	}
	
	public static boolean isSpaceChar(int c) {
		return c == ' ' || c == '\n' || c == '\r' || c == '\t' || c == -1;
	}
}
