public class squares {
  int[] paint(int n) {
  	int[] labels = new int[n + 1];
  	for (int i = 0; i < n + 1; i++) {
  	  labels[i] = 1;
  	}
  	return labels;
  }

  int find_location(int n, int[] c) {
    return 0;
  }
}
