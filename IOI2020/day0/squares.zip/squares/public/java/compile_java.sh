#!/bin/bash

problem=squares
grader_name=grader

set -e
rm -f "${problem}.jar" *.class
javac "${grader_name}.java" "${problem}.java"
jar cfe "${problem}.jar" "${grader_name}" *.class
