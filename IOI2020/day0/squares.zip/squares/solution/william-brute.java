public class squares {
  int[] paint(int n) {
    int[] painting = new int[n + 1];
    for (int i = 0; i < n; i++) {
      painting[i] = 0;
    }
    painting[n] = n;
  	return painting;
  }

  int find_location(int n, int[] c) {
    for (int i = 0; i < c.length; i++) {
      if (c[i] == -1) return n - i;
    }
    return 0;
  }
}
