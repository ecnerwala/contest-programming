#include "squares.h"

std::vector<int> paint(int n) {
  std::vector<int> painting(n, 0);
  painting.push_back(n);
  return painting;
}

int find_location(int n, std::vector<int> c) {
  for (int i = 0; i < (int)c.size(); i++) {
    if (c[i] == -1) return n - i;
  }
  return 0;
}
