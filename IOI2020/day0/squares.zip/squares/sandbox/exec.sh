#!/bin/bash

problem_name=squares
sandbox=$(dirname "$0")

"${sandbox}/${problem_name}.exe" "$@"
