#include "squares.h"
#include <cassert>
#include <cstdio>
#include <string>
#include <vector>

using namespace std;

static FILE *fin;
static FILE *fout;

int main(int argc, char **argv) {
	if (argc != 4) {
		fprintf(stderr, "grader error\n");
		fprintf(stderr, "number of arguments isn't 4\n");
		exit(0);
	}
	
	fin = fopen(argv[1], "r");
	fout = fopen(argv[2], "a");
	
	if (string(argv[3]) == "0") { // grader A
		int r;
		if (fscanf(fin, "%d", &r) != 1) {
			fprintf(stderr, "grader A error\n");
			fprintf(stderr, "could not read 'r'\n");
			exit(0);
		}
		for (int i = 0; i < r; i++) {
			int n;
			if (fscanf(fin, "%d", &n) != 1) {
				fprintf(stderr, "grader A error\n");
				fprintf(stderr, "could not read 'n'\n");
				exit(0);
			}
			if (n < 0) { // error in labels
				exit(0);
			}
			vector<int> painting = paint(n);
			fprintf(fout, "%d\n", (int)painting.size());
			if ((int)painting.size() != n + 1) {
				fflush(fout);
				exit(0);
			}
			for (int j : painting) {
				fprintf(fout, "%d\n", j);
			}
			fflush(fout);
		}
	} else if (string(argv[3]) == "1") { 
		int q;
		if (fscanf(fin, "%d", &q) != 1) {
			fprintf(stderr, "grader B error\n");
			fprintf(stderr, "could not read 'q'\n");
			exit(0);
		}
		if (q < 0) { // error in labels
			exit(0);
		}
		for (int i = 0; i < q; i++) {
			int n, k, l; // l is the number of not -1 squares
			if (fscanf(fin, "%d%d%d", &n, &k, &l) != 3) {
				fprintf(stderr, "grader B error\n");
				fprintf(stderr, "could not read query\n");
				exit(0);
			}
			if (n < 0 || k < 0 || l < 0) { // error in answer
				exit(0);
			}
			vector<int> c(k);
			int count = 0, val = 0;
			for (int j = 0; j < l; j++) {
				if (count == 0) {
					// each integer represents 32 painted squares
					if (fscanf(fin, "%d", &val) != 1) {
						fprintf(stderr, "grader B error\n");
						fprintf(stderr, "could not read squares\n");
						exit(0);
					}
					count = 32;
				}
				c[j] = val & 1;
				val >>= 1;
				--count;
			}
			for (int j = l; j < k; j++) {
				c[j] = -1;
			}
			fprintf(fout, "%d\n", find_location(n, c));
			fflush(fout);
		}
	} else {
		fprintf(stderr, "grader error\n");
		fprintf(stderr, "unknown grader type %s\n", argv[3]);
		exit(0);
	}
	return 0;
}
