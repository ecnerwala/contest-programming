#include <algorithm>
#include <cmath>
#include <cstdio>
#include <map>
#include <vector>
#include <set>

using namespace std;

const int MAXR = 10;
const int MAXN = 1000;
const int MAXQ = 1000;

FILE *grader1in,*grader1out, *grader2in, *grader2out;
int r, max_k = 0, k_limit, is_partial, seed;
int n[MAXR], q[MAXR], k[MAXR];
int labels[MAXR][MAXN], x[MAXR][MAXQ];
vector<pair<int, int>> queries;

static void shuffle(vector<pair<int, int>> &v){
	srand(seed);
	random_shuffle(v.begin(), v.end());
}

inline void die(bool sendDie) {
	if (sendDie) {
	  fprintf(grader2out, "-1\n");
	  fflush(grader2out);
	}
	printf("0\n");
	fprintf(stderr, "Wrong Answer\n");
	exit(0);
}

int main(int argc, char **argv) {
	grader1out = fopen(argv[2], "a");
	grader1in = fopen(argv[1], "r");
	grader2out = fopen(argv[4], "a");
	grader2in = fopen(argv[3], "r");
	
	// read in test input
	scanf("%d", &r);
	for (int i = 0; i < r; i++) {
		scanf("%d%d", &n[i], &q[i]);
		for (int j = 0; j < q[i]; j++) {
			scanf("%d", &x[i][j]);
		}
	}
	scanf("%d%d%d", &k_limit, &is_partial, &seed);
	fclose(stdin);
	
	// send trees to first grader for relabeling
	fprintf(grader1out, "%d\n", r);
	fflush(grader1out);
	for (int i = 0; i < r; i++) {
		fprintf(grader1out, "%d\n", n[i]);
		fflush(grader1out);
		int m;
		if (fscanf(grader1in, "%d", &m) != 1 || m != n[i] + 1) {
			die(true);
		}
		for(int j = 0; j < n[i]; j++) {
			if (fscanf(grader1in, "%d", &labels[i][j]) != 1) {
				die(true);
			}
		}
		if (fscanf(grader1in, "%d", &k[i]) != 1) {
			die(true);
		}
	}
	fclose(grader1out);
	fclose(grader1in);
	
	// check whether labels are valid then generate and shuffle queries
	for (int i = 0; i < r; i++) {
		// check labels
		for (int j = 0; j < n[i]; j++) {
			if (labels[i][j] < 0 || labels[i][j] > 1) {
				die(true);
			}
		}
		
		if (k[i] < 0 || k[i] > k_limit) {
			die(true);
		}
		max_k = max(max_k, k[i]);
		
		// add query
		for (int j = 0; j < q[i]; j++) {
			queries.emplace_back(i, x[i][j]);
		}
	}
	shuffle(queries);
	
	// send queries
	bool fail = 0;
	fprintf(grader2out, "%d\n", (int)queries.size());
	fflush(grader2out);
	for (const pair<int, int>& q : queries) {
		int idx = q.first, ans = q.second;
		fprintf(grader2out, "%d %d %d\n", n[idx], k[idx], min(k[idx], n[idx] - ans));
		int count = 0, val = 0;
		for (int i = ans; i < min(ans + k[idx], n[idx]); i++) {
			if (count == 32) {
				fprintf(grader2out, "%d\n", val);
				count = 0;
				val = 0;
			}
			val |= (labels[idx][i] << (count++));
		}
		fprintf(grader2out, "%d\n", val);
		fflush(grader2out);
		int chosen;
		if (fscanf(grader2in, "%d", &chosen) != 1) {
			die(false);
		}
		if (chosen != ans) {
			fail = 1;
		}
	}
	fclose(grader2in);
	fclose(grader2out);
	
	// print score
	if (fail) {
		printf("0\n");
		fprintf(stderr, "Wrong Answer\n");
	} else if (!is_partial) { // non-partial scoring
		printf("1\n");
		fprintf(stderr, "Correct\n");
	} else { // partial scoring
		long double points = 0;
		if (max_k <= 10) {
			points = 55;
			fprintf(stderr, "Correct\n");
		} else if (max_k < 30) {
			points = (30 - max_k) * 55 / 20.0;
			fprintf(stderr, "Partially correct\n");
		} else {
			points = 0;
			fprintf(stderr, "Wrong Answer\n");
		}
		points /= 55;
		printf("%lf\n", (double)points);
	}
	return 0;
}
