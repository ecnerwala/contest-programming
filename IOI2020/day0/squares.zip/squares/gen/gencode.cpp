#include "testlib.h"
using namespace std;

struct test_case {
  int n, q;
};
typedef struct test_case test_case;
vector<test_case> test_cases;

vector<int> queries;

void gen_queries(int n, int q) {
	queries.clear();
	if (q < n) {
		for (int i = 0; i < q; i++) {
			queries.push_back(rnd.next(n));
		}
	} else {
		for (int i = 0; i < n; i++) {
			queries.push_back(i);
		}
		for (int i = n; i < q; i++) {
			queries.push_back(rnd.next(n));
		}
	}
}

int main(int argc, char **argv) {
  // read in test cases
	registerGen(argc, argv, 1);
	int r = atoi(argv[1]);
	int index = 2;
	for (int i = 0; i < r; i++) {
	  test_case tc;
	  tc.n = atoi(argv[index++]);
	  tc.q = atoi(argv[index++]);
	  test_cases.push_back(tc);
	}
	
	printf("%d\n", r);
	shuffle(test_cases.begin(), test_cases.end());
	for (int i = 0; i < r; i++) {
		auto& tc = test_cases[i];
	  gen_queries(tc.n, tc.q);
	  printf("%d %d\n", tc.n, tc.q);
	  shuffle(queries.begin(), queries.end());
	  for (int q : queries) {
	  	printf("%d\n", q);
	  }
	}
	printf("%d ", atoi(argv[index++]));
	printf("%d %d\n", atoi(argv[index++]), rnd.next(INT_MAX));
	return 0;
}