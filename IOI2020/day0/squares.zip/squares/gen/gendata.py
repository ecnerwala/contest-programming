print("@subtask samples")
print("manual sample-01.in");
print("");

n = [2, 3, 5, 10, 100, 500, 900, 950, 990, 1000]

# Subtask 1
print("@subtask k1000");
print("gencode 10", end = '')
for i in range(10):
  print(" %d 1000" % (n[i]), end = '')
print(" 1000 0")

print("gencode 10", end = '')
for i in range(10):
  print(" %d 1000" % (1000 - i), end = '')
print(" 1000 0")

print("")

# Subtask 2
print("@subtask k100")
print("gencode 10", end = '')
for i in range(10):
  print(" %d 1000" % (n[i]), end = '')
print(" 100 0")

print("gencode 10", end = '')
for i in range(10):
  print(" %d 1000" % (1000 - i), end = '')
print(" 100 0")

print("")

# Subtask 3
print("@subtask k70")
print("gencode 10", end = '')
for i in range(10):
  print(" %d 1000" % (n[i]), end = '')
print(" 70 0")

print("gencode 10", end = '')
for i in range(10):
  print(" %d 1000" % (1000 - i), end = '')
print(" 70 0")

print("")

# Subtask 4
print("@subtask partial")
print("gencode 10", end = '')
for i in range(10):
  print(" %d 1000" % (n[i]), end = '')
print(" 30 1")

print("gencode 10", end = '')
for i in range(10):
  print(" %d 1000" % (1000 - i), end = '')
print(" 30 1")
