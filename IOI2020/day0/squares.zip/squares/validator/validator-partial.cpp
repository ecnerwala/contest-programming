#include "testlib.h"
using namespace std;

const int MAXR = 10;
const int MAXN = 1000;
const int MAXQ = 1000;
const int MAXK = 1000;

int main() {
	registerValidation();
	int r = inf.readInt(1, MAXR, "r");
	inf.readEoln(); 
	for (int i = 0; i < r; i++) {
		int n = inf.readInt(2, MAXN, "n");
		inf.readSpace();
		int q = inf.readInt(2, MAXQ, "q");
		inf.readEoln();
		for (int j = 0; j < q; j++) {
			inf.readInt(0, n - 1, "x_i");
			inf.readEoln();
		}
	}
	
	inf.readInt(30, 30, "k");
	inf.readSpace();
	inf.readInt(1, 1, "is_partial");
	inf.readSpace();
	inf.readInt(0, INT_MAX, "seed");
	inf.readEoln();
	inf.readEof();
	return 0;
}
